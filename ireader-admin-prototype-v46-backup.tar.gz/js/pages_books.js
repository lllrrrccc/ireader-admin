Object.assign(pageFunctions, {
books: () => `
<div class="page-title">
    <span>书籍管理</span>
    <div style="display:flex;gap:8px;">
        <button class="btn btn-primary" onclick="navigateTo('batchAddBooks')"><i class="ri-stack-line"></i> 批量新增</button>
        <button class="btn btn-primary" onclick="openModal('modal-add-article')"><i class="ri-add-line"></i> 新增文章</button>
    </div>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>书籍名称</label>
        <input type="text" class="form-input" placeholder="模糊搜索">
    </div>
    <div class="filter-group">
        <label>ISBN</label>
        <input type="text" class="form-input" placeholder="模糊搜索">
    </div>
    <div class="filter-group" style="margin-left:100px;">
        <label>基础分类</label>
        <div class="multiselect-dropdown" id="book-filter-cat" style="position:relative;width:160px;">
            <div class="multiselect-trigger" style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border:1px solid var(--border);border-radius:var(--radius);cursor:pointer;background:#fff;" onclick="toggleDropdown(this, 'book-filter-cat-opts')">
                <span id="book-filter-cat-text" style="font-size:13px;color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0;">全部</span>
                <i class="ri-arrow-down-s-line" style="color:var(--text-muted);flex-shrink:0;margin-left:4px;"></i>
            </div>
            <div class="multiselect-options" id="book-filter-cat-opts" style="display:none;position:fixed;z-index:10000;background:#fff;border:1px solid var(--border);border-radius:var(--radius);max-height:240px;overflow-y:auto;box-shadow:0 8px 24px rgba(0,0,0,0.15);min-width:180px;">
                <div style="padding:8px 12px;border-bottom:1px solid var(--border);font-size:12px;color:var(--text-muted);font-weight:600;">中文</div>
                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('book-filter-cat')"> 文学</label>
                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('book-filter-cat')"> 艺术</label>
                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('book-filter-cat')"> 人文社科</label>
                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('book-filter-cat')"> 自然科学</label>
                <div style="padding:8px 12px;border-bottom:1px solid var(--border);border-top:1px solid var(--border);font-size:12px;color:var(--text-muted);font-weight:600;">英文</div>
                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('book-filter-cat')"> 英语周报时文</label>
                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('book-filter-cat')"> 外研社分级阅读</label>
                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('book-filter-cat')"> 原版名著</label>
            </div>
        </div>
    </div>
    <div class="filter-group">
        <label>适用年级</label>
        <select class="form-select">
            <option>全部</option>
            <option>小学1-2年级</option>
            <option>小学3-4年级</option>
            <option>小学5-6年级</option>
            <option>初中</option>
            <option>高中</option>
        </select>
    </div>
    <div class="filter-group">
        <label>状态</label>
        <select class="form-select">
            <option>全部</option>
            <option>可见</option>
            <option>隐藏</option>
        </select>
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
    </div>
</div>

<div class="card">
    <div class="card-body" style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width:120px;">ID</th>
                    <th style="width:120px;">ISBN</th>
                    <th>书籍名称</th>
                    <th>作者</th>
                    <th>基础分类</th>
                    <th>适用年级</th>
                    <th>文件类型</th>
                    <th>状态</th>
                    <th style="width:180px;">操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>CH2606120001</td>
                    <td>978-7-020-00001-1</td>
                    <td>小王子</td>
                    <td>圣埃克苏佩里</td>
                    <td>中文-文学</td>
                    <td>小学3-4年级</td>
                    <td><span class="tag tag-blue">电子书</span></td>
                    <td><span class="tag tag-green">可见</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('bookDetail')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openBookStatusModal('modal-book-hide', 'CH2606120001')"><i class="ri-eye-off-line"></i> 隐藏</button>
                        <button class="btn btn-link btn-sm" style="color:var(--info);" onclick="navigateTo('bookAudio')"><i class="ri-music-2-line"></i> 音频</button>
                    </td>
                </tr>
                <tr>
                    <td>CH2606120002</td>
                    <td>978-7-020-00002-2</td>
                    <td>夏洛的网</td>
                    <td>E·B·怀特</td>
                    <td>中文-文学</td>
                    <td>小学3-4年级</td>
                    <td><span class="tag tag-blue">电子书</span></td>
                    <td><span class="tag tag-green">可见</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('bookDetail')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openBookStatusModal('modal-book-hide', 'CH2606120002')"><i class="ri-eye-off-line"></i> 隐藏</button>
                        <button class="btn btn-link btn-sm" style="color:var(--info);" onclick="navigateTo('bookAudio')"><i class="ri-music-2-line"></i> 音频</button>
                    </td>
                </tr>
                <tr>
                    <td>CH2606120003</td>
                    <td>978-7-020-00003-3</td>
                    <td>哈利·波特与魔法石</td>
                    <td>J.K.罗琳</td>
                    <td>中文-文学</td>
                    <td>小学5-6年级</td>
                    <td><span class="tag tag-blue">电子书</span></td>
                    <td><span class="tag tag-green">可见</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('bookDetail')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openBookStatusModal('modal-book-hide', 'CH2606120003')"><i class="ri-eye-off-line"></i> 隐藏</button>
                        <button class="btn btn-link btn-sm" style="color:var(--info);" onclick="navigateTo('bookAudio')"><i class="ri-music-2-line"></i> 音频</button>
                    </td>
                </tr>
                <tr>
                    <td>EN2606120001</td>
                    <td>978-0-15-601-219-5</td>
                    <td><span style="display:block;">The Little Prince</span><span style="font-size:12px;color:var(--text-muted);">小王子</span></td>
                    <td><span style="display:block;">Antoine de Saint-Exupéry</span><span style="font-size:12px;color:var(--text-muted);">圣埃克苏佩里</span></td>
                    <td>英文-原版名著</td>
                    <td>初中</td>
                    <td><span class="tag tag-purple">文章</span></td>
                    <td><span class="tag tag-green">可见</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('bookDetail')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openBookStatusModal('modal-book-hide', 'EN2606120001')"><i class="ri-eye-off-line"></i> 隐藏</button>
                        <button class="btn btn-link btn-sm" style="color:var(--info);" onclick="navigateTo('bookAudioEn')"><i class="ri-music-2-line"></i> 音频</button>
                    </td>
                </tr>
                <tr>
                    <td>CH2606120004</td>
                    <td>978-7-020-00004-4</td>
                    <td>西游记</td>
                    <td>吴承恩</td>
                    <td>中文-文学</td>
                    <td>初中</td>
                    <td><span class="tag tag-blue">电子书</span></td>
                    <td><span class="tag tag-gray">隐藏</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('bookDetail')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--success);" onclick="openBookStatusModal('modal-book-show', 'CH2606120004')"><i class="ri-eye-line"></i> 可见</button>
                        <button class="btn btn-link btn-sm" style="color:var(--info);" onclick="navigateTo('bookAudio')"><i class="ri-music-2-line"></i> 音频</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 128 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<!-- 新增文章弹窗 -->
<div class="modal-overlay" id="modal-add-article">
    <div class="modal" style="max-width:720px;">
        <div class="modal-header">
            <span class="modal-title">新增文章</span>
            <button class="modal-close" onclick="closeModal('modal-add-article')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="padding:20px 0;">
            <div class="form-group">
                <label class="form-label">语言类型 <span style="color:var(--danger);">*</span></label>
                <select class="form-select" id="article-lang-select" onchange="toggleArticleLangFields()">
                    <option value="">请选择</option>
                    <option value="zh">中文</option>
                    <option value="en">英文</option>
                </select>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group" id="article-name-en-group" style="display:none;">
                    <label class="form-label">书籍名称英文 <span style="color:var(--danger);">*</span></label>
                    <input type="text" class="form-input" id="article-name-en" placeholder="请输入英文书名" onblur="generateArticleCover()">
                </div>
                <div class="form-group" id="article-name-zh-group">
                    <label class="form-label">书籍名称 <span style="color:var(--danger);">*</span></label>
                    <input type="text" class="form-input" id="article-name-zh" placeholder="请输入中文书名" onblur="generateArticleCover()">
                </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group" id="article-author-en-group" style="display:none;">
                    <label class="form-label">作者英文名字 <span style="color:var(--danger);">*</span></label>
                    <input type="text" class="form-input" placeholder="请输入作者英文名">
                </div>
                <div class="form-group" id="article-author-zh-group">
                    <label class="form-label">作者 <span style="color:var(--danger);">*</span></label>
                    <input type="text" class="form-input" placeholder="请输入作者名">
                </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group">
                    <label class="form-label">ISBN</label>
                    <input type="text" class="form-input" placeholder="请输入ISBN">
                </div>
                <div class="form-group">
                    <label class="form-label">出版社</label>
                    <input type="text" class="form-input" placeholder="请输入出版社">
                </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group">
                    <label class="form-label">基础分类 <span style="color:var(--danger);">*</span></label>
                    <div class="multiselect-dropdown" id="article-cat" style="position:relative;">
                        <div class="multiselect-trigger" style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border:1px solid var(--border);border-radius:var(--radius);cursor:pointer;background:#fff;" onclick="toggleDropdown(this, 'article-cat-opts')">
                            <span id="article-cat-text" style="font-size:13px;color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0;">请选择</span>
                            <i class="ri-arrow-down-s-line" style="color:var(--text-muted);flex-shrink:0;margin-left:4px;"></i>
                        </div>
                        <div class="multiselect-options" id="article-cat-opts" style="display:none;position:fixed;z-index:10000;background:#fff;border:1px solid var(--border);border-radius:var(--radius);max-height:240px;overflow-y:auto;box-shadow:0 8px 24px rgba(0,0,0,0.15);min-width:180px;">
                            <div style="padding:8px 12px;border-bottom:1px solid var(--border);font-size:12px;color:var(--text-muted);font-weight:600;">中文</div>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="article-cat" onchange="updateRadioText('article-cat', '中文-文学')"> 文学</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="article-cat" onchange="updateRadioText('article-cat', '中文-艺术')"> 艺术</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="article-cat" onchange="updateRadioText('article-cat', '中文-人文社科')"> 人文社科</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="article-cat" onchange="updateRadioText('article-cat', '中文-自然科学')"> 自然科学</label>
                            <div style="padding:8px 12px;border-bottom:1px solid var(--border);border-top:1px solid var(--border);font-size:12px;color:var(--text-muted);font-weight:600;">英文</div>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="article-cat" onchange="updateRadioText('article-cat', '英文-英语周报时文')"> 英语周报时文</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="article-cat" onchange="updateRadioText('article-cat', '英文-外研社分级阅读')"> 外研社分级阅读</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="article-cat" onchange="updateRadioText('article-cat', '英文-原版名著')"> 原版名著</label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">适用年级 <span style="color:var(--danger);">*</span></label>
                    <div class="multiselect-dropdown" id="article-grade" style="position:relative;">
                        <div class="multiselect-trigger" style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border:1px solid var(--border);border-radius:var(--radius);cursor:pointer;background:#fff;" onclick="toggleDropdown(this, 'article-grade-opts')">
                            <span id="article-grade-text" style="font-size:13px;color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0;">请选择（可多选）</span>
                            <i class="ri-arrow-down-s-line" style="color:var(--text-muted);flex-shrink:0;margin-left:4px;"></i>
                        </div>
                        <div class="multiselect-options" id="article-grade-opts" style="display:none;position:fixed;z-index:10000;background:#fff;border:1px solid var(--border);border-radius:var(--radius);max-height:240px;overflow-y:auto;box-shadow:0 8px 24px rgba(0,0,0,0.15);min-width:180px;">
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 小学1年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 小学2年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 小学3年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 小学4年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 小学5年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 小学6年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 初中1年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 初中2年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 初中3年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 高中一年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 高中二年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 高中三年级</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 大学生</label>
                            <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="checkbox" onchange="updateGradeText('article-grade')"> 在职人员</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">书籍封面 <span style="color:var(--danger);">*</span></label>
                <div style="display:flex;gap:12px;align-items:flex-start;">
                    <div id="article-cover-preview" style="width:80px;height:115px;border-radius:6px;background:var(--bg);display:flex;align-items:center;justify-content:center;color:var(--text-muted);font-size:12px;text-align:center;padding:4px;flex-shrink:0;box-shadow:0 2px 6px rgba(0,0,0,0.1);border:1px dashed var(--border);">
                        <i class="ri-image-line" style="font-size:24px;"></i>
                    </div>
                    <div style="display:flex;flex-direction:column;gap:8px;justify-content:center;flex:1;">
                        <button class="btn btn-secondary" onclick="document.getElementById('article-cover-upload').click()" style="align-self:flex-start;"><i class="ri-upload-2-line"></i> 上传封面图</button>
                        <span style="font-size:12px;color:var(--text-muted);line-height:1.5;">建议尺寸：272×392px<br>图片格式：jpg、png<br>或将自动根据书名合成封面</span>
                        <input type="file" id="article-cover-upload" accept="image/jpeg,image/png" style="display:none;">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">书籍简介 <span style="color:var(--danger);">*</span></label>
                <textarea class="form-textarea" rows="3" placeholder="请输入书籍简介（最多400字）"></textarea>
                <div style="font-size:12px;color:var(--text-muted);margin-top:4px;text-align:right;">0/400</div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-add-article')">取消</button>
            <button class="btn btn-primary" onclick="saveArticle()">确认保存</button>
        </div>
    </div>
</div>

<!-- 新增书籍弹窗 — 两步向导 -->
<div class="modal-overlay" id="modal-add-book">
    <div class="modal" style="max-width:640px;">
        <div class="modal-header">
            <span class="modal-title">新增书籍</span>
            <button class="modal-close" onclick="closeModal('modal-add-book')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <!-- Step 1: 上传EPUB -->
            <div id="add-book-step1" style="text-align:center;padding:40px 20px;">
                <i class="ri-book-open-line" style="font-size:56px;color:var(--primary);margin-bottom:16px;"></i>
                <div style="font-size:16px;font-weight:600;margin-bottom:8px;">上传电子书</div>
                <div style="font-size:13px;color:var(--text-secondary);margin-bottom:24px;">请上传 EPUB 格式的电子书文件，系统将自动提取书籍信息</div>
                <div style="border:2px dashed var(--primary);border-radius:12px;padding:40px 24px;background:rgba(37,99,235,0.04);cursor:pointer;" onclick="document.getElementById('epub-upload').click()">
                    <i class="ri-upload-cloud-2-line" style="font-size:40px;color:var(--primary);margin-bottom:12px;"></i>
                    <p style="font-size:14px;color:var(--text-primary);font-weight:500;margin:0 0 4px 0;">点击上传或拖拽文件到此处</p>
                    <p style="font-size:12px;color:var(--text-muted);margin:0;">支持 EPUB 格式，最大 50MB</p>
                    <input type="file" id="epub-upload" accept=".epub" style="display:none;" onchange="showBookStep2()">
                </div>
                <div style="margin-top:20px;padding:10px 16px;background:var(--bg);border-radius:6px;display:none;" id="epub-file-name">
                    <i class="ri-file-3-line" style="color:var(--primary);margin-right:6px;"></i>
                    <span style="font-size:13px;">the_little_prince.epub</span>
                </div>
            </div>
            <!-- Step 2: 提取信息+编辑 -->
            <div id="add-book-step2" style="display:none;">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div class="form-group">
                        <label class="form-label">书籍名称 <span style="color:var(--danger);">*</span></label>
                        <input type="text" class="form-input" value="The Little Prince">
                    </div>
                    <div class="form-group">
                        <label class="form-label">作者 <span style="color:var(--danger);">*</span></label>
                        <input type="text" class="form-input" value="Antoine de Saint-Exupéry">
                    </div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div class="form-group">
                        <label class="form-label">ISBN</label>
                        <input type="text" class="form-input" value="978-0-15-601-219-5">
                    </div>
                    <div class="form-group">
                        <label class="form-label">出版社</label>
                        <input type="text" class="form-input" value="Harcourt">
                    </div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div class="form-group">
                        <label class="form-label">基础分类 <span style="color:var(--danger);">*</span></label>
                        <div class="multiselect-dropdown" id="add-book-cat" style="position:relative;">
                            <div class="multiselect-trigger" style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border:1px solid var(--border);border-radius:var(--radius);cursor:pointer;background:#fff;" onclick="toggleDropdown(this, 'add-book-cat-opts')">
                                <span id="add-book-cat-text" style="font-size:13px;color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0;">请选择</span>
                                <i class="ri-arrow-down-s-line" style="color:var(--text-muted);flex-shrink:0;margin-left:4px;"></i>
                            </div>
                            <div class="multiselect-options" id="add-book-cat-opts" style="display:none;position:fixed;z-index:10000;background:#fff;border:1px solid var(--border);border-radius:var(--radius);max-height:240px;overflow-y:auto;box-shadow:0 8px 24px rgba(0,0,0,0.15);min-width:180px;">
                                <div style="padding:8px 12px;border-bottom:1px solid var(--border);font-size:12px;color:var(--text-muted);font-weight:600;">中文</div>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="add-book-cat" onchange="updateRadioText('add-book-cat', '中文-文学')"> 文学</label>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="add-book-cat" onchange="updateRadioText('add-book-cat', '中文-艺术')"> 艺术</label>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="add-book-cat" onchange="updateRadioText('add-book-cat', '中文-人文社科')"> 人文社科</label>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="add-book-cat" onchange="updateRadioText('add-book-cat', '中文-自然科学')"> 自然科学</label>
                                <div style="padding:8px 12px;border-bottom:1px solid var(--border);border-top:1px solid var(--border);font-size:12px;color:var(--text-muted);font-weight:600;">英文</div>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="add-book-cat" onchange="updateRadioText('add-book-cat', '英文-英语周报时文')"> 英语周报时文</label>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="add-book-cat" onchange="updateRadioText('add-book-cat', '英文-外研社分级阅读')"> 外研社分级阅读</label>
                                <label style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;font-size:13px;transition:background 0.2s;" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''"><input type="radio" name="add-book-cat" onchange="updateRadioText('add-book-cat', '英文-原版名著')"> 原版名著</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">适用年级 <span style="color:var(--danger);">*</span></label>
                        <select class="form-select">
                            <option>请选择</option>
                            <option>小学1-2年级</option>
                            <option>小学3-4年级</option>
                            <option>小学5-6年级</option>
                            <option>初中</option>
                            <option>高中</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">书籍封面</label>
                    <div style="display:flex;gap:12px;align-items:flex-start;">
                        <div style="width:80px;height:115px;border-radius:6px;background:#4A90D9;display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:500;text-align:center;padding:4px;flex-shrink:0;box-shadow:0 2px 6px rgba(0,0,0,0.1);">
                            The Little Prince
                        </div>
                        <div style="display:flex;flex-direction:column;gap:8px;justify-content:center;flex:1;">
                            <button class="btn btn-secondary" onclick="document.getElementById('cover-upload').click()" style="align-self:flex-start;"><i class="ri-upload-2-line"></i> 上传封面图</button>
                            <span style="font-size:12px;color:var(--text-muted);line-height:1.5;">建议尺寸：272×392px<br>图片格式：jpg、png</span>
                            <input type="file" id="cover-upload" accept="image/jpeg,image/png" style="display:none;">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">书籍简介</label>
                    <textarea class="form-textarea" rows="3" placeholder="请输入书籍简介">A timeless tale about a little prince from a distant planet who travels through the universe, learning about love, loss and friendship.</textarea>
                </div>
            </div>
        </div>
        <div class="modal-footer" id="add-book-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-add-book')">取消</button>
            <button class="btn btn-primary" onclick="showBookStep2()">下一步 <i class="ri-arrow-right-line"></i></button>
        </div>
    </div>
</div>

<!-- 删除音频确认模态框 -->
<div class="modal-overlay" id="modal-delete-audio">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-audio')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:32px 20px;">
            <i class="ri-error-warning-line" style="font-size:48px;color:var(--danger);margin-bottom:16px;"></i>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">确定要删除该音频吗？</div>
            <div style="font-size:13px;color:var(--text-secondary);">删除后该音频的时间轴标记数据也将被清除</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-audio')">取消</button>
            <button class="btn btn-danger">确认删除</button>
        </div>
    </div>
</div>


<!-- AI导读模态框 -->
<div class="modal-overlay" id="modal-book-ai">
    <div class="modal" style="max-width:840px;">
        <div class="modal-header">
            <span class="modal-title">AI导读配置</span>
            <button class="modal-close" onclick="closeModal('modal-book-ai')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">AI导读开关</label>
                <div style="display:flex;align-items:center;gap:8px;">
                    <div style="width:40px;height:22px;background:var(--success);border-radius:11px;position:relative;cursor:pointer;">
                        <div style="width:18px;height:18px;background:#fff;border-radius:50%;position:absolute;top:2px;right:2px;box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>
                    </div>
                    <span style="font-size:13px;color:var(--text-secondary);">已开启</span>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">导读风格</label>
                <select class="form-select">
                    <option>生动活泼</option>
                    <option>简洁严谨</option>
                    <option>学术深度</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">AI导读内容预览</label>
                <div style="padding:12px;background:var(--bg);border-radius:8px;font-size:13px;line-height:1.6;color:var(--text-secondary);">
                    <i class="ri-lightbulb-flash-line" style="color:var(--warning);margin-right:4px;"></i>
                    小王子讲述了一位来自 B-612 星球的小王子的旅程。故事通过孩子的视角，揭示了成人世界的空虚与盲目，强调了真诚、友谊和爱的重要性……
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-book-ai')">取消</button>
            <button class="btn btn-primary">保存配置</button>
        </div>
    </div>
</div>

<!-- 确认隐藏书籍模态框 -->
<div class="modal-overlay" id="modal-book-hide">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认隐藏</span>
            <button class="modal-close" onclick="closeModal('modal-book-hide')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:24px 20px;">
            <i class="ri-error-warning-line" style="font-size:40px;color:var(--warning);margin-bottom:12px;"></i>
            <div style="font-size:14px;color:var(--text-primary);line-height:1.6;">
                书籍隐藏后，所有用户<span style="color:var(--danger);font-weight:600;">都不能</span>在阅览室看到这本书。
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-book-hide')">取消</button>
            <button class="btn btn-primary" onclick="toggleBookVisibility(false)">确认隐藏</button>
        </div>
    </div>
</div>

<!-- 确认可见书籍模态框 -->
<div class="modal-overlay" id="modal-book-show">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认可见</span>
            <button class="modal-close" onclick="closeModal('modal-book-show')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:24px 20px;">
            <i class="ri-checkbox-circle-line" style="font-size:40px;color:var(--success);margin-bottom:12px;"></i>
            <div style="font-size:14px;color:var(--text-primary);line-height:1.6;">
                书籍可见后，所有用户均可在阅览室看到这本书。
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-book-show')">取消</button>
            <button class="btn btn-primary" onclick="toggleBookVisibility(true)">确认可见</button>
        </div>
    </div>
</div>
`,


bookAudio: () => `
<div class="page-title">
    <button class="btn btn-link" onclick="navigateTo('books')"><i class="ri-arrow-left-line"></i> 返回书籍列表</button>
    <span>音频管理</span>
</div>

<div class="card">
    <div class="card-body" style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>音频名称</th>
                    <th>生成方式</th>
                    <th>状态</th>
                    <th>最近修改时间</th>
                    <th style="width:200px;">操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>女声</td>
                    <td>AI生成</td>
                    <td><span class="tag tag-green">可选</span></td>
                    <td>2026/3/13 10:00</td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('audioAlignment')"><i class="ri-scissors-line"></i> 音文对齐</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="toggleAudioSelectable(this)"><i class="ri-eye-off-line"></i> 不可选</button>
                    </td>
                </tr>
                <tr>
                    <td>男声</td>
                    <td>AI生成</td>
                    <td><span class="tag tag-gray">不可选</span></td>
                    <td>2026/2/16 14:32</td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('audioAlignment')"><i class="ri-scissors-line"></i> 音文对齐</button>
                        <button class="btn btn-link btn-sm" style="color:var(--success);" onclick="toggleAudioSelectable(this)"><i class="ri-eye-line"></i> 可选</button>
                    </td>
                </tr>
                <tr>
                    <td>原声</td>
                    <td>手动上传</td>
                    <td><span class="tag tag-green">可选</span></td>
                    <td>2026/2/13 09:26</td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('audioAlignmentEn')"><i class="ri-scissors-line"></i> 音文对齐</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="toggleAudioSelectable(this)"><i class="ri-eye-off-line"></i> 不可选</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 3 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<!-- 删除音频确认模态框 -->
<div class="modal-overlay" id="modal-delete-audio">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-audio')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:32px 20px;">
            <i class="ri-error-warning-line" style="font-size:48px;color:var(--danger);margin-bottom:16px;"></i>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">确定要删除该音频吗？</div>
            <div style="font-size:13px;color:var(--text-secondary);">删除后该音频的文字定位数据也将被清除</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-audio')">取消</button>
            <button class="btn btn-danger">确认删除</button>
        </div>
    </div>
</div>
`,


bookAudioEn: () => `
<div class="page-title">
    <button class="btn btn-link" onclick="navigateTo('books')"><i class="ri-arrow-left-line"></i> 返回书籍列表</button>
    <span>音频管理</span>
</div>

<div class="card">
    <div class="card-body" style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>音频名称</th>
                    <th>生成方式</th>
                    <th>状态</th>
                    <th>最近修改时间</th>
                    <th style="width:200px;">操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>女声</td>
                    <td>AI生成</td>
                    <td><span class="tag tag-green">可选</span></td>
                    <td>2026/3/13 10:00</td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('audioAlignmentEn')"><i class="ri-scissors-line"></i> 音文对齐</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="toggleAudioSelectable(this)"><i class="ri-eye-off-line"></i> 不可选</button>
                    </td>
                </tr>
                <tr>
                    <td>男声</td>
                    <td>AI生成</td>
                    <td><span class="tag tag-gray">不可选</span></td>
                    <td>2026/2/16 14:32</td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('audioAlignmentEn')"><i class="ri-scissors-line"></i> 音文对齐</button>
                        <button class="btn btn-link btn-sm" style="color:var(--success);" onclick="toggleAudioSelectable(this)"><i class="ri-eye-line"></i> 可选</button>
                    </td>
                </tr>
                <tr>
                    <td>原声</td>
                    <td>手动上传</td>
                    <td><span class="tag tag-green">可选</span></td>
                    <td>2026/2/13 09:26</td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm" onclick="navigateTo('audioAlignmentEn')"><i class="ri-scissors-line"></i> 音文对齐</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="toggleAudioSelectable(this)"><i class="ri-eye-off-line"></i> 不可选</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 3 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<!-- 删除音频确认模态框 -->
<div class="modal-overlay" id="modal-delete-audio">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-audio')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:32px 20px;">
            <i class="ri-error-warning-line" style="font-size:48px;color:var(--danger);margin-bottom:16px;"></i>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">确定要删除该音频吗？</div>
            <div style="font-size:13px;color:var(--text-secondary);">删除后该音频的文字定位数据也将被清除</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-audio')">取消</button>
            <button class="btn btn-danger">确认删除</button>
        </div>
    </div>
</div>
`,


batchAddBooks: () => `
<div class="page-title">
    <span>批量新增书籍</span>
    <button class="btn btn-secondary" onclick="navigateTo('books')"><i class="ri-arrow-left-line"></i> 返回列表</button>
</div>

<!-- 步骤条 -->
<div class="steps" style="margin-bottom:24px;">
    <div class="step active" id="batch-step-1">
        <div class="step-number">1</div>
        <span class="step-label">上传文件</span>
    </div>
    <div class="step" id="batch-step-2">
        <div class="step-number">2</div>
        <span class="step-label">编辑书籍信息</span>
    </div>
    <div class="step" id="batch-step-3">
        <div class="step-number">3</div>
        <span class="step-label">完成</span>
    </div>
</div>

<!-- Step 1: 上传文件 -->
<div id="batch-upload-step">
    <div class="card">
        <div class="card-body">
            <div style="border:2px dashed var(--primary);border-radius:12px;padding:60px 40px;text-align:center;background:rgba(37,99,235,0.04);cursor:pointer;" onclick="document.getElementById('batch-files').click()">
                <i class="ri-upload-cloud-2-line" style="font-size:48px;color:var(--primary);margin-bottom:16px;"></i>
                <div style="font-size:16px;font-weight:600;color:var(--text-primary);margin-bottom:8px;">点击上传或拖拽文件到此处</div>
                <div style="font-size:13px;color:var(--text-muted);">支持 EPUB 格式，最多可上传 50 本</div>
                <input type="file" id="batch-files" multiple accept=".epub" style="display:none;" onchange="handleBatchFiles(this)">
            </div>
            <div style="margin-top:20px;display:flex;justify-content:space-between;align-items:center;">
                <div style="font-size:13px;color:var(--text-secondary);">
                    <i class="ri-file-list-3-line" style="margin-right:4px;"></i>
                    已上传 <strong id="batch-count" style="color:var(--primary);">0</strong> / 50 本
                </div>
                <button class="btn btn-primary" id="batch-next-btn" disabled onclick="showBatchStep2()"><i class="ri-arrow-right-line"></i> 下一步</button>
            </div>
        </div>
    </div>
    
    <!-- 已上传文件列表 -->
    <div class="card" id="batch-file-list-card" style="display:none;">
        <div class="card-header"><span class="card-title">📁 已上传文件</span></div>
        <div class="card-body" id="batch-file-list" style="display:flex;flex-direction:column;gap:8px;">
        </div>
    </div>
</div>

<!-- Step 2: 编辑书籍信息 -->
<div id="batch-edit-step" style="display:none;">
    <div class="card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
            <span class="card-title">📖 解析结果 — 共 <span id="batch-edit-count">0</span> 本</span>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-secondary btn-sm" onclick="showBatchStep1()"><i class="ri-arrow-left-line"></i> 上一步</button>
                <button class="btn btn-primary btn-sm" onclick="showBatchStep3()"><i class="ri-save-line"></i> 确定新增</button>
            </div>
        </div>
        <div class="card-body" style="overflow-x:auto;">
            <table class="data-table" id="batch-edit-table">
                <thead>
                    <tr>
                        <th style="width:40px;"><input type="checkbox" id="batch-check-all" onclick="toggleBatchCheckAll()"></th>
                        <th>书名</th>
                        <th>作者</th>
                        <th>ISBN</th>
                        <th style="width:180px;">
                            <div style="display:flex;flex-direction:column;gap:4px;">
                                <select class="form-select" style="width:100%;font-weight:400;" id="batch-bulk-cat">
                                    <option>设置基础分类</option>
                                    <option>中文-文学</option>
                                    <option>中文-艺术</option>
                                    <option>中文-人文社科</option>
                                    <option>中文-自然科学</option>
                                    <option>英文-英语周报时文</option>
                                    <option>英文-外研社分级阅读</option>
                                    <option>英文-原版名著</option>
                                </select>
                                <span>基础分类</span>
                            </div>
                        </th>
                        <th style="width:140px;">
                            <div style="display:flex;flex-direction:column;gap:4px;">
                                <select class="form-select" style="width:100%;font-weight:400;" id="batch-bulk-grade">
                                    <option>设置适用年级</option>
                                    <option>小学1-2年级</option>
                                    <option>小学3-4年级</option>
                                    <option>小学5-6年级</option>
                                    <option>初中</option>
                                    <option>高中</option>
                                </select>
                                <span>适用年级</span>
                            </div>
                        </th>
                        <th>
                            <div style="display:flex;flex-direction:column;gap:4px;">
                                <button class="btn btn-secondary btn-sm" style="width:100%;font-weight:400;" onclick="applyBatchEdit()"><i class="ri-check-line"></i> 应用</button>
                                <span>状态</span>
                            </div>
                        </th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody id="batch-edit-tbody">
                </tbody>
            </table>
        </div>
        <div class="card-footer" style="display:flex;justify-content:flex-end;align-items:center;padding:12px 20px;border-top:1px solid var(--border);">
            <div style="display:flex;gap:8px;">
                <button class="btn btn-secondary" onclick="showBatchStep1()"><i class="ri-arrow-left-line"></i> 上一步</button>
                <button class="btn btn-primary" onclick="showBatchStep3()"><i class="ri-save-line"></i> 确定新增</button>
            </div>
        </div>
    </div>
</div>

<!-- Step 3: 完成 -->
<div id="batch-done-step" style="display:none;">
    <div class="empty-state" style="padding:80px 20px;">
        <i class="ri-checkbox-circle-line" style="font-size:64px;color:var(--success);margin-bottom:20px;"></i>
        <div style="font-size:18px;font-weight:600;color:var(--text-primary);margin-bottom:8px;">新增成功！</div>
        <div style="font-size:14px;color:var(--text-secondary);margin-bottom:24px;">共新增 <strong id="batch-done-count" style="color:var(--primary);">0</strong> 本书籍</div>
        <button class="btn btn-primary" onclick="navigateTo('books')"><i class="ri-arrow-left-line"></i> 返回书籍列表</button>
    </div>
</div>
`,


bookDetail: () => `
<div class="page-title" style="justify-content:flex-start;gap:12px;">
    <button class="btn btn-secondary" onclick="navigateTo('books')"><i class="ri-arrow-left-line"></i> 返回列表</button>
    <span>书籍详情</span>
</div>

<!-- 查看模式 -->
<div id="book-detail-view">
    <div class="card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
            <span class="card-title">📖 基本信息</span>
            <button class="btn btn-primary btn-sm" onclick="toggleBookEdit(true)"><i class="ri-edit-line"></i> 编辑</button>
        </div>
        <div class="card-body">
            <div style="display:flex;gap:16px;">
                <img src="assets/book_cover_icon.png" style="width:120px;border-radius:8px;flex-shrink:0;">
                <div style="flex:1;">
                    <h3 style="margin:0 0 8px 0;">小王子</h3>
                    <p style="margin:4px 0;color:var(--text-muted);font-size:13px;"><i class="ri-barcode-line"></i> ID：CH2606120001</p>
                    <p style="margin:4px 0;color:var(--text-muted);font-size:13px;"><i class="ri-barcode-line"></i> ISBN：978-7-020-00001-1</p>
                    <p style="margin:4px 0;color:var(--text-muted);font-size:13px;"><i class="ri-user-line"></i> 作者：圣埃克苏佩里</p>
                    <p style="margin:4px 0;color:var(--text-muted);font-size:13px;"><i class="ri-bookmark-line"></i> 基础分类：中文-文学</p>
                    <p style="margin:4px 0;color:var(--text-muted);font-size:13px;"><i class="ri-school-line"></i> 适用年级：小学3-4年级</p>
                    <p style="margin:4px 0;color:var(--text-muted);font-size:13px;"><i class="ri-building-line"></i> 出版社：人民文学出版社</p>
                    <p style="margin:4px 0;"><span class="tag tag-green">可见</span></p>
                </div>
            </div>
            <div class="form-group" style="margin-top:12px;">
                <label class="form-label">简介</label>
                <p style="font-size:13px;color:var(--text-muted);line-height:1.6;">小王子是一个来自B-612星球的小男孩，他在宇宙中旅行，探访了不同的星球，最终来到地球。通过他的眼睛，我们看到了成人世界的荒诞和荒谬，也重新认识了爱、责任和友谊的真谛。</p>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
            <span class="card-title">📊 阅读数据</span>
            <button class="btn btn-link btn-sm" onclick="navigateTo('readingData')"><i class="ri-eye-line"></i> 查看详细学生阅读数据</button>
        </div>
        <div class="card-body">
            <div class="stat-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px;">
                <div class="stat-card">
                    <span class="stat-value">3,245</span>
                    <span class="stat-label">总阅读人数</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">86%</span>
                    <span class="stat-label">完读率</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">12.5</span>
                    <span class="stat-label">平均阅读天数</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">4.8</span>
                    <span class="stat-label">平均评分</span>
                </div>
            </div>
            <div>
                <div style="font-size:13px;color:var(--text-muted);margin-bottom:8px;">阅读进度分布</div>
                <div style="display:flex;align-items:center;gap:8px;font-size:12px;">
                    <span style="width:60px;">未开始</span>
                    <div style="flex:1;height:16px;background:var(--bg);border-radius:8px;overflow:hidden;"><div style="width:14%;height:100%;background:var(--text-muted);"></div></div>
                    <span style="width:40px;">14%</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;font-size:12px;margin-top:4px;">
                    <span style="width:60px;">进行中</span>
                    <div style="flex:1;height:16px;background:var(--bg);border-radius:8px;overflow:hidden;"><div style="width:32%;height:100%;background:var(--warning);"></div></div>
                    <span style="width:40px;">32%</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;font-size:12px;margin-top:4px;">
                    <span style="width:60px;">已读完</span>
                    <div style="flex:1;height:16px;background:var(--bg);border-radius:8px;overflow:hidden;"><div style="width:54%;height:100%;background:var(--success);"></div></div>
                    <span style="width:40px;">54%</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 编辑模式 -->
<div id="book-detail-edit" style="display:none;">
    <div class="card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
            <span class="card-title">✏️ 编辑基本信息</span>
            <button class="btn btn-secondary btn-sm" onclick="toggleBookEdit(false)">取消</button>
        </div>
        <div class="card-body">
            <div style="display:flex;gap:16px;">
                <div style="flex-shrink:0;">
                    <img src="assets/book_cover_icon.png" style="width:120px;border-radius:8px;">
                    <div style="border:2px dashed var(--border);border-radius:6px;padding:8px;text-align:center;color:var(--text-muted);cursor:pointer;margin-top:8px;font-size:12px;" onclick="document.getElementById('detail-cover-upload').click()">
                        <i class="ri-upload-2-line"></i> 更换封面
                        <p style="font-size:11px;color:var(--text-muted);margin:2px 0 0 0;">272×392px</p>
                        <input type="file" id="detail-cover-upload" accept="image/*" style="display:none;">
                    </div>
                </div>
                <div style="flex:1;">
                    <div class="form-group">
                        <label class="form-label">书籍名称</label>
                        <input type="text" class="form-input" value="小王子">
                    </div>
                    <div class="form-group">
                        <label class="form-label">ISBN</label>
                        <input type="text" class="form-input" value="978-7-020-00001-1">
                    </div>
                    <div class="form-group">
                        <label class="form-label">作者</label>
                        <input type="text" class="form-input" value="圣埃克苏佩里">
                    </div>
                    <div class="form-group">
                        <label class="form-label">出版社</label>
                        <input type="text" class="form-input" value="人民文学出版社">
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                        <div class="form-group">
                            <label class="form-label">基础分类</label>
                            <select class="form-select">
                                <option>中文-文学</option>
                                <option>中文-艺术</option>
                                <option>中文-人文社科</option>
                                <option>中文-自然科学</option>
                                <option>英文-英语周报时文</option>
                                <option>英文-外研社分级阅读</option>
                                <option>英文-原版名著</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">适用年级</label>
                            <select class="form-select">
                                <option>小学1-2年级</option>
                                <option selected>小学3-4年级</option>
                                <option>小学5-6年级</option>
                                <option>初中</option>
                                <option>高中</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">状态</label>
                        <select class="form-select">
                            <option selected>可见</option>
                            <option>隐藏</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-group" style="margin-top:12px;">
                <label class="form-label">简介</label>
                <textarea class="form-textarea" rows="4">小王子是一个来自B-612星球的小男孩，他在宇宙中旅行，探访了不同的星球，最终来到地球。通过他的眼睛，我们看到了成人世界的荒诞和荒谬，也重新认识了爱、责任和友谊的真谛。</textarea>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px;">
                <button class="btn btn-secondary" onclick="toggleBookEdit(false)">取消</button>
                <button class="btn btn-primary" onclick="toggleBookEdit(false)"><i class="ri-save-line"></i> 保存修改</button>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;">
            <span class="card-title">📊 阅读数据</span>
            <button class="btn btn-link btn-sm" onclick="navigateTo('readingData')"><i class="ri-eye-line"></i> 查看详细学生阅读数据</button>
        </div>
        <div class="card-body">
            <div class="stat-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px;">
                <div class="stat-card">
                    <span class="stat-value">3,245</span>
                    <span class="stat-label">总阅读人数</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">86%</span>
                    <span class="stat-label">完读率</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">12.5</span>
                    <span class="stat-label">平均阅读天数</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">4.8</span>
                    <span class="stat-label">平均评分</span>
                </div>
            </div>
            <div>
                <div style="font-size:13px;color:var(--text-muted);margin-bottom:8px;">阅读进度分布</div>
                <div style="display:flex;align-items:center;gap:8px;font-size:12px;">
                    <span style="width:60px;">未开始</span>
                    <div style="flex:1;height:16px;background:var(--bg);border-radius:8px;overflow:hidden;"><div style="width:14%;height:100%;background:var(--text-muted);"></div></div>
                    <span style="width:40px;">14%</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;font-size:12px;margin-top:4px;">
                    <span style="width:60px;">进行中</span>
                    <div style="flex:1;height:16px;background:var(--bg);border-radius:8px;overflow:hidden;"><div style="width:32%;height:100%;background:var(--warning);"></div></div>
                    <span style="width:40px;">32%</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;font-size:12px;margin-top:4px;">
                    <span style="width:60px;">已读完</span>
                    <div style="flex:1;height:16px;background:var(--bg);border-radius:8px;overflow:hidden;"><div style="width:54%;height:100%;background:var(--success);"></div></div>
                    <span style="width:40px;">54%</span>
                </div>
            </div>
        </div>
    </div>
</div>
`,

audioAlignment: () => `
<div class="page-title">
    <button class="btn btn-link" onclick="navigateTo('bookAudio')"><i class="ri-arrow-left-line"></i> 返回音频管理</button>
    <span>音文对齐</span>
</div>

<div style="display:flex;flex-direction:column;gap:16px;height:calc(100vh - 160px);min-height:500px;">
    <!-- 顶部：音频信息 + 章节选择 + 上传 -->
    <div class="card" style="flex-shrink:0;">
        <div class="card-body" style="padding:12px 16px;">
            <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <i class="ri-volume-up-line" style="font-size:24px;color:var(--primary);"></i>
                    <div>
                        <div style="font-size:13px;font-weight:600;">原声</div>
                    </div>
                </div>
                <div style="margin-left:auto;display:flex;align-items:center;gap:8px;">
                    <span style="font-size:13px;font-weight:600;">《小王子》</span>
                    <span style="font-size:12px;color:var(--text-muted);">|</span>
                    <label style="font-size:13px;color:var(--text-secondary);">当前章节：</label>
                    <select class="form-select" style="width:160px;font-size:13px;padding:6px 10px;">
                        <option>第一章 小行星</option>
                        <option>第二章 玫瑰花</option>
                        <option>第三章 狐狸</option>
                        <option>第四章 飞行员</option>
                        <option>第五章 告别</option>
                    </select>
                    <button class="btn btn-secondary btn-sm" style="padding:6px 12px;font-size:12px;" onclick="document.getElementById('chapter-audio-upload').click()">
                        <i class="ri-upload-cloud-2-line" style="margin-right:4px;"></i>上传本章节音频
                    </button>
                    <input type="file" id="chapter-audio-upload" accept="audio/mp3,audio/wav" style="display:none;" onchange="handleChapterAudioUpload(this)">
                </div>
            </div>
        </div>
    </div>

    <!-- 上传中状态提示（默认隐藏） -->
    <div id="upload-progress" class="card" style="flex-shrink:0;display:none;">
        <div class="card-body" style="display:flex;align-items:center;gap:12px;">
            <i class="ri-loader-4-line" style="font-size:20px;color:var(--primary);animation:spin 1s linear infinite;"></i>
            <div style="flex:1;">
                <div style="font-size:13px;font-weight:500;">正在自动对齐中...</div>
                <div style="height:4px;background:var(--bg);border-radius:2px;margin-top:8px;overflow:hidden;">
                    <div style="width:60%;height:100%;background:var(--primary);border-radius:2px;"></div>
                </div>
            </div>
            <span style="font-size:12px;color:var(--text-muted);">60%</span>
        </div>
    </div>

    <!-- 时间轴编辑区域 -->
    <div class="card" style="flex:1;display:flex;flex-direction:column;overflow:hidden;">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;flex-shrink:0;">
            <span class="card-title">📝 时间轴编辑</span>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-secondary btn-sm" onclick="addTimelineRow()"><i class="ri-add-line"></i> 新增分句</button>
                <button class="btn btn-primary btn-sm" onclick="saveTimeline()"><i class="ri-save-line"></i> 保存</button>
            </div>
        </div>
        <div class="card-body" style="flex:1;overflow-y:auto;padding:12px;">
            <div style="display:flex;flex-direction:column;gap:8px;" id="timeline-list">
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="1">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">1</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:00:000" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">When I was six years old, in a book about primeval forests called 'True Stories', I saw a magnificent illustration.</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="2">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">2</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:15:320" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">It was a picture of a boa constrictor in the act of swallowing an animal.</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="3">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">3</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:28:150" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">Here is a copy of the drawing. In the book it said: "Boa constrictors swallow their prey whole, without chewing it."</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="4">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">4</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:42:890" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">I pondered deeply, then, over the adventures of the jungle. And after some work with a colored pencil I succeeded in making my first drawing.</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 底部音频播放器 -->
<div style="position:fixed;bottom:0;left:var(--sidebar-width);right:0;background:#fff;border-top:1px solid var(--border);padding:10px 20px;display:flex;align-items:center;gap:12px;z-index:100;">
    <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;min-width:120px;">
        <i class="ri-music-2-line" style="color:var(--primary);font-size:16px;"></i>
        <span style="font-size:12px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:90px;" id="audio-name-display">女声.mp3</span>
    </div>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="回退 5s"><i class="ri-rewind-fill" style="font-size:16px;"></i></button>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="回退 0.5s"><i class="ri-rewind-mini-fill" style="font-size:16px;"></i></button>
    <button class="btn btn-primary" style="width:36px;height:36px;border-radius:50%;padding:0;font-size:16px;flex-shrink:0;display:flex;align-items:center;justify-content:center;"><i class="ri-play-fill" style="font-size:18px;"></i></button>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="快进 0.5s"><i class="ri-speed-mini-fill" style="font-size:16px;"></i></button>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="快进 5s"><i class="ri-speed-fill" style="font-size:16px;"></i></button>
    <div style="flex:1;display:flex;flex-direction:column;gap:4px;">
        <!-- 波形背景 -->
        <div style="height:20px;background:var(--bg);border-radius:10px;position:relative;overflow:hidden;display:flex;align-items:center;gap:1px;padding:0 4px;">
            <div style="width:2px;height:6px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:20px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:8px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
        </div>
        <!-- 进度条（高度8px，不超过10px） -->
        <div style="height:8px;background:var(--bg);border-radius:4px;position:relative;overflow:hidden;">
            <div style="position:absolute;left:0;top:0;bottom:0;width:35%;background:var(--primary);border-radius:4px;"></div>
            <div style="position:absolute;left:35%;top:0;bottom:0;width:2px;background:#fff;"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-muted);font-variant-numeric:tabular-nums;">
            <span>01:23:456</span>
            <span>06:15:789</span>
        </div>
    </div>
</div>

<!-- 删除分句确认弹窗 -->
<div class="modal-overlay" id="modal-delete-sentence">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-sentence')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:24px 20px;">
            <i class="ri-error-warning-line" style="font-size:40px;color:var(--danger);margin-bottom:12px;"></i>
            <div style="font-size:14px;color:var(--text-primary);line-height:1.6;">删除当前分句后，将无法恢复，是否确认删除？</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-sentence')">取消</button>
            <button class="btn btn-danger" onclick="confirmDeleteSentence()">确认删除</button>
        </div>
    </div>
</div>

<style>
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
</style>
`,

audioAlignmentEn: () => `
<div class="page-title">
    <button class="btn btn-link" onclick="navigateTo('bookAudioEn')"><i class="ri-arrow-left-line"></i> 返回音频管理</button>
    <span>音文对齐</span>
</div>

<div style="display:flex;flex-direction:column;gap:16px;height:calc(100vh - 160px);min-height:500px;">
    <!-- 顶部：音频信息 + 章节选择 + 上传 -->
    <div class="card" style="flex-shrink:0;">
        <div class="card-body" style="padding:12px 16px;">
            <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <i class="ri-volume-up-line" style="font-size:24px;color:var(--primary);"></i>
                    <div>
                        <div style="font-size:13px;font-weight:600;">原声</div>
                    </div>
                </div>
                <div style="margin-left:auto;display:flex;align-items:center;gap:8px;">
                    <span style="font-size:13px;font-weight:600;">《The Little Prince/小王子》</span>
                    <span style="font-size:12px;color:var(--text-muted);">|</span>
                    <label style="font-size:13px;color:var(--text-secondary);">当前章节：</label>
                    <select class="form-select" style="width:160px;font-size:13px;padding:6px 10px;">
                        <option>第一章 小行星</option>
                        <option>第二章 玫瑰花</option>
                        <option>第三章 狐狸</option>
                        <option>第四章 飞行员</option>
                        <option>第五章 告别</option>
                    </select>
                    <button class="btn btn-secondary btn-sm" style="padding:6px 12px;font-size:12px;" onclick="document.getElementById('chapter-audio-upload').click()">
                        <i class="ri-upload-cloud-2-line" style="margin-right:4px;"></i>上传本章节音频
                    </button>
                    <input type="file" id="chapter-audio-upload" accept="audio/mp3,audio/wav" style="display:none;" onchange="handleChapterAudioUpload(this)">
                </div>
            </div>
        </div>
    </div>

    <!-- 上传中状态提示（默认隐藏） -->
    <div id="upload-progress" class="card" style="flex-shrink:0;display:none;">
        <div class="card-body" style="display:flex;align-items:center;gap:12px;">
            <i class="ri-loader-4-line" style="font-size:20px;color:var(--primary);animation:spin 1s linear infinite;"></i>
            <div style="flex:1;">
                <div style="font-size:13px;font-weight:500;">正在自动对齐中...</div>
                <div style="height:4px;background:var(--bg);border-radius:2px;margin-top:8px;overflow:hidden;">
                    <div style="width:60%;height:100%;background:var(--primary);border-radius:2px;"></div>
                </div>
            </div>
            <span style="font-size:12px;color:var(--text-muted);">60%</span>
        </div>
    </div>

    <!-- 时间轴编辑区域 -->
    <div class="card" style="flex:1;display:flex;flex-direction:column;overflow:hidden;">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;flex-shrink:0;">
            <span class="card-title">📝 时间轴编辑</span>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-secondary btn-sm" onclick="addTimelineRow()"><i class="ri-add-line"></i> 新增分句</button>
                <button class="btn btn-primary btn-sm" onclick="saveTimeline()"><i class="ri-save-line"></i> 保存</button>
            </div>
        </div>
        <div class="card-body" style="flex:1;overflow-y:auto;padding:12px;">
            <div style="display:flex;flex-direction:column;gap:8px;" id="timeline-list">
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="1">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">1</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:00:000" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">When I was six years old, in a book about primeval forests called 'True Stories', I saw a magnificent illustration.</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="2">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">2</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:15:320" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">It was a picture of a boa constrictor in the act of swallowing an animal.</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="3">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">3</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:28:150" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">Here is a copy of the drawing. In the book it said: "Boa constrictors swallow their prey whole, without chewing it."</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
                <div style="display:flex;gap:8px;align-items:flex-start;padding:10px;background:var(--bg);border-radius:8px;border:1px solid transparent;" onmouseover="this.style.borderColor='var(--primary)'" onmouseout="this.style.borderColor='transparent'" data-timeline-index="4">
                    <span style="flex-shrink:0;width:24px;height:24px;background:var(--primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;">4</span>
                    <div style="flex-shrink:0;width:100px;">
                        <input type="text" class="form-input" style="font-size:12px;padding:5px 6px;text-align:center;font-variant-numeric:tabular-nums;" value="00:00:42:890" placeholder="HH:MM:SS:mmm">
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:12px;" onclick="markTimelineTime(this)"><i class="ri-flag-line"></i> 标记</button>
                    </div>
                    <div style="flex:1;max-width:840px;">
                        <textarea class="form-textarea" rows="2" style="font-size:13px;line-height:1.5;resize:vertical;min-height:60px;" placeholder="对应文本段落">I pondered deeply, then, over the adventures of the jungle. And after some work with a colored pencil I succeeded in making my first drawing.</textarea>
                    </div>
                    <div style="flex-shrink:0;display:flex;flex-direction:row;gap:8px;align-items:center;">
                        <button class="btn btn-link btn-sm" style="color:var(--danger);padding:2px 6px;font-size:14px;" onclick="showDeleteSentenceModal(this)" title="删除分句"><i class="ri-delete-bin-line"></i></button>
                        <button class="btn btn-link btn-sm" style="padding:2px 6px;font-size:14px;" onclick="addTimelineAfter(this)" title="添加分句"><i class="ri-add-line"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 底部音频播放器 -->
<div style="position:fixed;bottom:0;left:var(--sidebar-width);right:0;background:#fff;border-top:1px solid var(--border);padding:10px 20px;display:flex;align-items:center;gap:12px;z-index:100;">
    <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;min-width:120px;">
        <i class="ri-music-2-line" style="color:var(--primary);font-size:16px;"></i>
        <span style="font-size:12px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:90px;" id="audio-name-display">女声.mp3</span>
    </div>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="回退 5s"><i class="ri-rewind-fill" style="font-size:16px;"></i></button>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="回退 0.5s"><i class="ri-rewind-mini-fill" style="font-size:16px;"></i></button>
    <button class="btn btn-primary" style="width:36px;height:36px;border-radius:50%;padding:0;font-size:16px;flex-shrink:0;display:flex;align-items:center;justify-content:center;"><i class="ri-play-fill" style="font-size:18px;"></i></button>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="快进 0.5s"><i class="ri-speed-mini-fill" style="font-size:16px;"></i></button>
    <button class="btn btn-secondary" style="width:32px;height:32px;border-radius:50%;padding:0;flex-shrink:0;font-size:14px;display:flex;align-items:center;justify-content:center;" title="快进 5s"><i class="ri-speed-fill" style="font-size:16px;"></i></button>
    <div style="flex:1;display:flex;flex-direction:column;gap:4px;">
        <!-- 波形背景 -->
        <div style="height:20px;background:var(--bg);border-radius:10px;position:relative;overflow:hidden;display:flex;align-items:center;gap:1px;padding:0 4px;">
            <div style="width:2px;height:6px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:20px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:8px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:19px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:10px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:15px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:18px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:11px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:21px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:12px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:16px;background:var(--primary);opacity:0.3;"></div>
            <div style="width:2px;height:14px;background:var(--primary);opacity:0.3;"></div>
        </div>
        <!-- 进度条（高度8px，不超过10px） -->
        <div style="height:8px;background:var(--bg);border-radius:4px;position:relative;overflow:hidden;">
            <div style="position:absolute;left:0;top:0;bottom:0;width:35%;background:var(--primary);border-radius:4px;"></div>
            <div style="position:absolute;left:35%;top:0;bottom:0;width:2px;background:#fff;"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-muted);font-variant-numeric:tabular-nums;">
            <span>01:23:456</span>
            <span>06:15:789</span>
        </div>
    </div>
</div>

<!-- 删除分句确认弹窗 -->
<div class="modal-overlay" id="modal-delete-sentence">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-sentence')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:24px 20px;">
            <i class="ri-error-warning-line" style="font-size:40px;color:var(--danger);margin-bottom:12px;"></i>
            <div style="font-size:14px;color:var(--text-primary);line-height:1.6;">删除当前分句后，将无法恢复，是否确认删除？</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-sentence')">取消</button>
            <button class="btn btn-danger" onclick="confirmDeleteSentence()">确认删除</button>
        </div>
    </div>
</div>

<style>
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
</style>
`,

bookTranslation: () => `
<div class="page-title">
    <button class="btn btn-link" onclick="navigateTo('books')"><i class="ri-arrow-left-line"></i> 返回书籍列表</button>
    <span>译文管理</span>
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title">🌐 译文列表</span>
        <button class="btn btn-primary btn-sm"><i class="ri-add-line"></i> 新增译文</button>
    </div>
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>语言</th>
                    <th>译者</th>
                    <th>状态</th>
                    <th>更新时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>中文（简体）</td>
                    <td>系统默认</td>
                    <td><span class="tag tag-green">已发布</span></td>
                    <td>2024-06-15 14:30</td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>中文（繁体）</td>
                    <td>张伟</td>
                    <td><span class="tag tag-yellow">审核中</span></td>
                    <td>2024-06-14 09:15</td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
`,

});
