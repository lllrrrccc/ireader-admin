// Auto-generated from pages.js
Object.assign(pageFunctions, {
recommendation: () => `
<div class="page-title">
    <span>推荐排序</span>
    <button class="btn btn-primary" onclick="openModal('modal-add-recommendation')"><i class="ri-add-line"></i> 添加推荐</button>
</div>

<div style="display:flex;gap:8px;margin-bottom:16px;">
    <button class="btn btn-primary btn-sm" style="flex:1;">首页推荐</button>
    <button class="btn btn-secondary btn-sm" style="flex:1;">书籍详情相关推荐</button>
</div>

<div class="card">
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>排序</th>
                    <th>书籍</th>
                    <th>分类</th>
                    <th>适用年级</th>
                    <th>推荐位</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 1</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/4A90D9/fff?text=书" style="border-radius:3px;"> 小王子</td>
                    <td><span class="tag">中文</span></td>
                    <td>小学3-4年级</td>
                    <td>首页banner</td>
                    <td><span class="tag tag-green">展示中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 2</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/E67E22/fff?text=书" style="border-radius:3px;"> 夏洛的网</td>
                    <td><span class="tag">中文</span></td>
                    <td>小学3-4年级</td>
                    <td>首页热门</td>
                    <td><span class="tag tag-green">展示中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 3</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/8E44AD/fff?text=EN" style="border-radius:3px;"> The Little Prince</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>初中</td>
                    <td>首页新书上架</td>
                    <td><span class="tag tag-green">展示中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 4</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/27AE60/fff?text=书" style="border-radius:3px;"> 西游记</td>
                    <td><span class="tag">中文</span></td>
                    <td>初中</td>
                    <td>首页热门</td>
                    <td><span class="tag tag-green">展示中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 5</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/C0392B/fff?text=书" style="border-radius:3px;"> 哈利·波特与魔法石</td>
                    <td><span class="tag">中文</span></td>
                    <td>小学5-6年级</td>
                    <td>首页banner</td>
                    <td><span class="tag tag-green">展示中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 6</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/F39C12/fff?text=EN" style="border-radius:3px;"> Charlotte's Web</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>小学5-6年级</td>
                    <td>书籍详情相关推荐</td>
                    <td><span class="tag tag-green">展示中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 7</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/1ABC9C/fff?text=书" style="border-radius:3px;"> 草房子</td>
                    <td><span class="tag">中文</span></td>
                    <td>小学3-4年级</td>
                    <td>首页新书上架</td>
                    <td><span class="tag tag-yellow">待展示</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
                <tr>
                    <td><i class="ri-drag-move-fill" style="color:var(--text-muted);"></i> 8</td>
                    <td style="display:flex;align-items:center;gap:8px;"><img src="https://via.placeholder.com/32x44/9B59B6/fff?text=EN" style="border-radius:3px;"> Harry Potter and the Sorcerer's Stone</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>初中</td>
                    <td>书籍详情相关推荐</td>
                    <td><span class="tag tag-green">展示中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-recommendation')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-recommendation')"><i class="ri-delete-bin-line"></i> 移除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 24 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<!-- 添加推荐模态框 -->
<div class="modal-overlay" id="modal-add-recommendation">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">添加推荐</span>
            <button class="modal-close" onclick="closeModal('modal-add-recommendation')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">推荐位</label>
                <select class="form-select">
                    <option>首页banner</option>
                    <option>首页热门</option>
                    <option>首页新书上架</option>
                    <option>书籍详情相关推荐</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">选择书籍</label>
                <input type="text" class="form-input" placeholder="搜索书籍名称">
            </div>
            <div class="form-group">
                <label class="form-label">排序</label>
                <input type="number" class="form-input" placeholder="数字越小越靠前">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-add-recommendation')">取消</button>
            <button class="btn btn-primary">确认添加</button>
        </div>
    </div>
</div>

<!-- 编辑推荐模态框 -->
<div class="modal-overlay" id="modal-edit-recommendation">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">编辑推荐</span>
            <button class="modal-close" onclick="closeModal('modal-edit-recommendation')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">推荐位</label>
                <select class="form-select">
                    <option>首页banner</option>
                    <option selected>首页热门</option>
                    <option>首页新书上架</option>
                    <option>书籍详情相关推荐</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">选择书籍</label>
                <input type="text" class="form-input" value="小王子">
            </div>
            <div class="form-group">
                <label class="form-label">排序</label>
                <input type="number" class="form-input" value="1">
            </div>
            <div class="form-group">
                <label class="form-label">状态</label>
                <select class="form-select">
                    <option selected>展示中</option>
                    <option>待展示</option>
                    <option>已下线</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-edit-recommendation')">取消</button>
            <button class="btn btn-primary">保存修改</button>
        </div>
    </div>
</div>

<!-- 删除确认模态框 -->
<div class="modal-overlay" id="modal-delete-recommendation">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认移除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-recommendation')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:32px 20px;">
            <i class="ri-error-warning-line" style="font-size:48px;color:var(--danger);margin-bottom:16px;"></i>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">确定要移除该推荐吗？</div>
            <div style="font-size:13px;color:var(--text-secondary);">移除后该书籍将不再显示在推荐位中</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-recommendation')">取消</button>
            <button class="btn btn-danger">确认移除</button>
        </div>
    </div>
</div>
`,


wordbank: () => `
<div class="page-title">
    <span>生词库管理</span>
    <button class="btn btn-primary" onclick="openModal('modal-add-wordbank')"><i class="ri-add-line"></i> 新增词库</button>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>词库名称</label>
        <input type="text" class="form-input" placeholder="搜索词库">
    </div>
    <div class="filter-group">
        <label>语言</label>
        <select class="form-select">
            <option>全部</option>
            <option>中文</option>
            <option>英文</option>
        </select>
    </div>
    <div class="filter-group">
        <label>关联书籍</label>
        <input type="text" class="form-input" placeholder="书籍名称">
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>词库名称</th>
                    <th>语言</th>
                    <th>词汇数量</th>
                    <th>关联书籍</th>
                    <th>创建时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>WB001</td>
                    <td>小王子核心词汇</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>128</td>
                    <td>小王子</td>
                    <td>2024-01-15</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>WB002</td>
                    <td>夏洛的网高频词</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>95</td>
                    <td>夏洛的网</td>
                    <td>2024-01-20</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>WB003</td>
                    <td>西游记成语典故</td>
                    <td><span class="tag">中文</span></td>
                    <td>256</td>
                    <td>西游记</td>
                    <td>2024-02-01</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>WB004</td>
                    <td>哈利·波特魔法词汇</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>168</td>
                    <td>哈利·波特与魔法石</td>
                    <td>2024-02-10</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>WB005</td>
                    <td>草房子优美词句</td>
                    <td><span class="tag">中文</span></td>
                    <td>88</td>
                    <td>草房子</td>
                    <td>2024-02-15</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>WB006</td>
                    <td>初中英语必背单词</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>500</td>
                    <td>—</td>
                    <td>2024-02-20</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>WB007</td>
                    <td>小学语文成语大全</td>
                    <td><span class="tag">中文</span></td>
                    <td>320</td>
                    <td>—</td>
                    <td>2024-03-01</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>WB008</td>
                    <td>The Little Prince 词汇</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>145</td>
                    <td>The Little Prince</td>
                    <td>2024-03-05</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-wordbank')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-wordbank')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 36 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<div class="modal-overlay" id="modal-add-wordbank">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">新增词库</span>
            <button class="modal-close" onclick="closeModal('modal-add-wordbank')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">词库名称</label>
                <input type="text" class="form-input" placeholder="请输入词库名称">
            </div>
            <div class="form-group">
                <label class="form-label">语言</label>
                <select class="form-select">
                    <option>中文</option>
                    <option>英文</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">关联书籍</label>
                <input type="text" class="form-input" placeholder="搜索并选择书籍">
            </div>
            <div class="form-group">
                <label class="form-label">词汇导入</label>
                <div style="border:2px dashed var(--border);border-radius:8px;padding:24px;text-align:center;color:var(--text-muted);">
                    <i class="ri-upload-cloud-2-line" style="font-size:32px;"></i>
                    <p style="margin:4px 0;font-size:13px;">上传CSV或Excel文件批量导入词汇</p>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-add-wordbank')">取消</button>
            <button class="btn btn-primary">确认创建</button>
        </div>
    </div>
</div>

<!-- 编辑词库模态框 -->
<div class="modal-overlay" id="modal-edit-wordbank">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">编辑词库</span>
            <button class="modal-close" onclick="closeModal('modal-edit-wordbank')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">词库名称</label>
                <input type="text" class="form-input" value="小王子核心词汇">
            </div>
            <div class="form-group">
                <label class="form-label">语言</label>
                <select class="form-select">
                    <option>中文</option>
                    <option selected>英文</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">关联书籍</label>
                <input type="text" class="form-input" value="小王子">
            </div>
            <div class="form-group">
                <label class="form-label">词汇数量</label>
                <input type="number" class="form-input" value="128">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-edit-wordbank')">取消</button>
            <button class="btn btn-primary">保存修改</button>
        </div>
    </div>
</div>

<!-- 删除确认模态框 -->
<div class="modal-overlay" id="modal-delete-wordbank">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-wordbank')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:32px 20px;">
            <i class="ri-error-warning-line" style="font-size:48px;color:var(--danger);margin-bottom:16px;"></i>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">确定要删除该词库吗？</div>
            <div style="font-size:13px;color:var(--text-secondary);">删除后词库中的词汇数据将无法恢复</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-wordbank')">取消</button>
            <button class="btn btn-danger">确认删除</button>
        </div>
    </div>
</div>

<!-- 查看词库模态框 -->
<div class="modal-overlay" id="modal-view-wordbank">
    <div class="modal" style="max-width:600px;">
        <div class="modal-header">
            <span class="modal-title">词库详情</span>
            <button class="modal-close" onclick="closeModal('modal-view-wordbank')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div style="display:flex;gap:16px;margin-bottom:16px;">
                <div style="flex:1;">
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">词库名称</div>
                    <div style="font-size:14px;font-weight:500;">小王子生词库</div>
                </div>
                <div style="flex:1;">
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">语言</div>
                    <div style="font-size:14px;font-weight:500;">中文</div>
                </div>
                <div style="flex:1;">
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">词汇数量</div>
                    <div style="font-size:14px;font-weight:500;">128</div>
                </div>
            </div>
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:8px;">词汇列表</div>
            <div style="max-height:300px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius);">
                <table class="data-table" style="margin:0;">
                    <thead>
                        <tr><th>词汇</th><th>音标</th><th>释义</th><th>难度</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>小王子</td><td></td><td>书名，来自B-612星球的小男孩</td><td><span class="tag">简单</span></td></tr>
                        <tr><td>驯养</td><td></td><td>建立联系，使彼此需要</td><td><span class="tag">中等</span></td></tr>
                        <tr><td>玫瑰</td><td></td><td>一种花，象征爱情</td><td><span class="tag">简单</span></td></tr>
                        <tr><td>狐狸</td><td></td><td>一种动物，智慧的象征</td><td><span class="tag">简单</span></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-view-wordbank')">关闭</button>
            <button class="btn btn-primary" onclick="closeModal('modal-view-wordbank');openModal('modal-edit-wordbank')"><i class="ri-edit-line"></i> 编辑</button>
        </div>
    </div>
</div>
`,


listening: () => `
<div class="page-title">
    <span>听力管理</span>
    <button class="btn btn-primary" onclick="openModal('modal-add-listening')"><i class="ri-add-line"></i> 新增听力</button>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>听力标题</label>
        <input type="text" class="form-input" placeholder="搜索标题">
    </div>
    <div class="filter-group">
        <label>语言</label>
        <select class="form-select">
            <option>全部</option>
            <option>中文</option>
            <option>英文</option>
        </select>
    </div>
    <div class="filter-group">
        <label>关联书籍</label>
        <input type="text" class="form-input" placeholder="书籍名称">
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>听力标题</th>
                    <th>语言</th>
                    <th>时长</th>
                    <th>关联书籍</th>
                    <th>播放次数</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>LS001</td>
                    <td>小王子 - 第一章</td>
                    <td><span class="tag">中文</span></td>
                    <td>12:35</td>
                    <td>小王子</td>
                    <td>1,245</td>
                    <td><span class="tag tag-green">已上架</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>LS002</td>
                    <td>夏洛的网 - 第一章</td>
                    <td><span class="tag">中文</span></td>
                    <td>15:20</td>
                    <td>夏洛的网</td>
                    <td>986</td>
                    <td><span class="tag tag-green">已上架</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>LS003</td>
                    <td>The Little Prince - Ch.1</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>10:45</td>
                    <td>The Little Prince</td>
                    <td>2,108</td>
                    <td><span class="tag tag-green">已上架</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>LS004</td>
                    <td>西游记 - 第一回</td>
                    <td><span class="tag">中文</span></td>
                    <td>18:30</td>
                    <td>西游记</td>
                    <td>756</td>
                    <td><span class="tag tag-green">已上架</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>LS005</td>
                    <td>哈利·波特 - 第一章</td>
                    <td><span class="tag">中文</span></td>
                    <td>22:15</td>
                    <td>哈利·波特与魔法石</td>
                    <td>3,420</td>
                    <td><span class="tag tag-green">已上架</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>LS006</td>
                    <td>Charlotte's Web - Ch.1</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>14:20</td>
                    <td>Charlotte's Web</td>
                    <td>1,876</td>
                    <td><span class="tag tag-green">已上架</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>LS007</td>
                    <td>草房子 - 第一章</td>
                    <td><span class="tag">中文</span></td>
                    <td>16:45</td>
                    <td>草房子</td>
                    <td>542</td>
                    <td><span class="tag tag-yellow">待审核</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>LS008</td>
                    <td>Harry Potter - Ch.1</td>
                    <td><span class="tag tag-blue">英文</span></td>
                    <td>20:10</td>
                    <td>Harry Potter and the Sorcerer's Stone</td>
                    <td>4,125</td>
                    <td><span class="tag tag-green">已上架</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-play-circle-line"></i> 播放</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-listening')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-listening')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 32 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<div class="modal-overlay" id="modal-add-listening">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">新增听力</span>
            <button class="modal-close" onclick="closeModal('modal-add-listening')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">听力标题</label>
                <input type="text" class="form-input" placeholder="请输入听力标题">
            </div>
            <div class="form-group">
                <label class="form-label">语言</label>
                <select class="form-select">
                    <option>中文</option>
                    <option>英文</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">关联书籍</label>
                <input type="text" class="form-input" placeholder="搜索并选择书籍">
            </div>
            <div class="form-group">
                <label class="form-label">音频文件</label>
                <div style="border:2px dashed var(--border);border-radius:8px;padding:24px;text-align:center;color:var(--text-muted);">
                    <i class="ri-upload-cloud-2-line" style="font-size:32px;"></i>
                    <p style="margin:4px 0;font-size:13px;">上传MP3或WAV音频文件</p>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-add-listening')">取消</button>
            <button class="btn btn-primary">确认创建</button>
        </div>
    </div>
</div>

<!-- 编辑听力模态框 -->
<div class="modal-overlay" id="modal-edit-listening">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">编辑听力</span>
            <button class="modal-close" onclick="closeModal('modal-edit-listening')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">听力标题</label>
                <input type="text" class="form-input" value="小王子 - 第一章">
            </div>
            <div class="form-group">
                <label class="form-label">语言</label>
                <select class="form-select">
                    <option selected>中文</option>
                    <option>英文</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">关联书籍</label>
                <input type="text" class="form-input" value="小王子">
            </div>
            <div class="form-group">
                <label class="form-label">时长</label>
                <input type="text" class="form-input" value="12:35">
            </div>
            <div class="form-group">
                <label class="form-label">状态</label>
                <select class="form-select">
                    <option selected>已上架</option>
                    <option>待审核</option>
                    <option>已下架</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-edit-listening')">取消</button>
            <button class="btn btn-primary">保存修改</button>
        </div>
    </div>
</div>

<!-- 删除确认模态框 -->
<div class="modal-overlay" id="modal-delete-listening">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-listening')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:32px 20px;">
            <i class="ri-error-warning-line" style="font-size:48px;color:var(--danger);margin-bottom:16px;"></i>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">确定要删除该听力资源吗？</div>
            <div style="font-size:13px;color:var(--text-secondary);">删除后学生将无法继续收听该音频</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-listening')">取消</button>
            <button class="btn btn-danger">确认删除</button>
        </div>
    </div>
</div>
`,


aiGuide: () => `
<div class="page-title">
    <span>AI 导读管理</span>
    <button class="btn btn-primary" onclick="openModal('modal-config-ai-guide')"><i class="ri-settings-3-line"></i> 配置AI导读</button>
</div>

<div class="two-col">
    <div class="card" style="flex:2;">
        <div class="card-header"><span class="card-title">⚙️ 提示词配置</span></div>
        <div class="card-body">
            <div class="form-group">
                <label class="form-label">系统角色设定</label>
                <textarea class="form-textarea" rows="4" placeholder="设定AI导读助手的角色和语气..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">导读生成模板</label>
                <textarea class="form-textarea" rows="4" placeholder="输入导读生成的模板提示词..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">模型选择</label>
                <select class="form-select">
                    <option>GPT-4</option>
                    <option>GPT-3.5</option>
                    <option>Claude 3</option>
                </select>
            </div>
            <div class="form-group" style="text-align:right;">
                <button class="btn btn-primary">保存配置</button>
            </div>
        </div>
    </div>
    <div class="card" style="flex:1;">
        <div class="card-header"><span class="card-title">📊 使用统计</span></div>
        <div class="card-body">
            <div class="stat-cards" style="grid-template-columns:1fr;">
                <div class="stat-card">
                    <span class="stat-value">5,432</span>
                    <span class="stat-label">总导读次数</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">2.1s</span>
                    <span class="stat-label">平均响应时间</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">98.5%</span>
                    <span class="stat-label">成功率</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><span class="card-title">📋 导读记录</span></div>
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>书籍</th>
                    <th>学生</th>
                    <th>导读内容摘要</th>
                    <th>生成时间</th>
                    <th>耗时</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>GD001</td>
                    <td>小王子</td>
                    <td>张三</td>
                    <td>这是一本关于成长与友谊的经典童话，讲述了小王子在各个星球...</td>
                    <td>2024-03-15 10:23</td>
                    <td>1.8s</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>GD002</td>
                    <td>夏洛的网</td>
                    <td>李四</td>
                    <td>关于一只蜘蛛和一头猪的友谊故事，展现了生命的珍贵...</td>
                    <td>2024-03-15 11:05</td>
                    <td>2.3s</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>GD003</td>
                    <td>西游记</td>
                    <td>王五</td>
                    <td>中国古代四大名著之一，讲述唐僧师徒西天取经的故事...</td>
                    <td>2024-03-15 14:12</td>
                    <td>3.1s</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>GD004</td>
                    <td>哈利·波特与魔法石</td>
                    <td>赵六</td>
                    <td>男孩哈利·波特进入霍格沃茨魔法学校的冒险故事...</td>
                    <td>2024-03-15 15:30</td>
                    <td>2.5s</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>GD005</td>
                    <td>草房子</td>
                    <td>钱七</td>
                    <td>桑桑在油麻地小学度过的六年小学生活，充满童真...</td>
                    <td>2024-03-15 16:45</td>
                    <td>1.9s</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>GD006</td>
                    <td>The Little Prince</td>
                    <td>孙八</td>
                    <td>A timeless tale about a little prince from a distant planet...</td>
                    <td>2024-03-15 17:20</td>
                    <td>2.2s</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>GD007</td>
                    <td>夏洛的网</td>
                    <td>周九</td>
                    <td>夏洛和威尔伯的友谊超越了物种的界限，温暖感人...</td>
                    <td>2024-03-15 18:00</td>
                    <td>2.7s</td>
                    <td><span class="tag tag-yellow">生成中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>GD008</td>
                    <td>小王子</td>
                    <td>吴十</td>
                    <td>通过小王子的旅程，探讨了爱、责任和人生的真谛...</td>
                    <td>2024-03-15 19:15</td>
                    <td>1.6s</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 56 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<!-- 配置AI导读模态框 -->
<div class="modal-overlay" id="modal-config-ai-guide">
    <div class="modal" style="max-width:600px;">
        <div class="modal-header">
            <span class="modal-title">配置AI导读</span>
            <button class="modal-close" onclick="closeModal('modal-config-ai-guide')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">AI导读开关</label>
                <div style="display:flex;align-items:center;gap:8px;">
                    <div style="width:40px;height:22px;background:var(--success);border-radius:11px;position:relative;cursor:pointer;">
                        <div style="width:18px;height:18px;background:#fff;border-radius:50%;position:absolute;top:2px;right:2px;box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>
                    </div>
                    <span style="font-size:13px;color:var(--text-secondary);">已开启</span>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">系统角色设定</label>
                <textarea class="form-textarea" rows="3" placeholder="设定AI导读助手的角色和语气...">你是一位亲切的阅读导师，擅长用生动有趣的方式为学生介绍书籍内容。</textarea>
            </div>
            <div class="form-group">
                <label class="form-label">导读生成模板</label>
                <textarea class="form-textarea" rows="3" placeholder="输入导读生成的模板提示词...">请为《{bookName}》生成一段简短的导读，适合{grade}学生阅读，重点介绍故事背景和主要人物。</textarea>
            </div>
            <div class="form-group">
                <label class="form-label">模型选择</label>
                <select class="form-select">
                    <option selected>GPT-4</option>
                    <option>GPT-3.5</option>
                    <option>Claude 3</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">最大响应字数</label>
                <input type="number" class="form-input" value="500">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-config-ai-guide')">取消</button>
            <button class="btn btn-primary">保存配置</button>
        </div>
    </div>
</div>
`,


aiTranslate: () => `
<div class="page-title">
    <span>AI 翻译管理</span>
</div>

<div class="two-col">
    <div class="card" style="flex:2;">
        <div class="card-header"><span class="card-title">⚙️ 翻译提示词配置</span></div>
        <div class="card-body">
            <div class="form-group">
                <label class="form-label">翻译风格</label>
                <select class="form-select">
                    <option>直译（忠实原文）</option>
                    <option>意译（流畅自然）</option>
                    <option>学术翻译</option>
                    <option>儿童友好翻译</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">系统提示词</label>
                <textarea class="form-textarea" rows="4" placeholder="设定AI翻译的风格和要求..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">模型选择</label>
                <select class="form-select">
                    <option>GPT-4</option>
                    <option>GPT-3.5</option>
                    <option>Claude 3</option>
                </select>
            </div>
            <div class="form-group" style="text-align:right;">
                <button class="btn btn-primary">保存配置</button>
            </div>
        </div>
    </div>
    <div class="card" style="flex:1;">
        <div class="card-header"><span class="card-title">📊 使用统计</span></div>
        <div class="card-body">
            <div class="stat-cards" style="grid-template-columns:1fr;">
                <div class="stat-card">
                    <span class="stat-value">12,856</span>
                    <span class="stat-label">总翻译次数</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">1.5s</span>
                    <span class="stat-label">平均响应时间</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">99.2%</span>
                    <span class="stat-label">成功率</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><span class="card-title">📋 翻译记录</span></div>
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>原文</th>
                    <th>译文</th>
                    <th>语言对</th>
                    <th>学生</th>
                    <th>生成时间</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>TR001</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">It is the time you have wasted for your rose...</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">正是你为你的玫瑰花费的时光，才使你的玫瑰变得如此重要...</td>
                    <td>EN → 中文</td>
                    <td>张三</td>
                    <td>2024-03-15 10:25</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>TR002</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Where there is life, there is hope.</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">哪里有生命，哪里就有希望。</td>
                    <td>EN → 中文</td>
                    <td>李四</td>
                    <td>2024-03-15 11:10</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>TR003</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">The stars are beautiful, because of a flower that cannot be seen.</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">星星真美，因为有一朵看不见的花。</td>
                    <td>EN → 中文</td>
                    <td>王五</td>
                    <td>2024-03-15 12:30</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>TR004</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">有朋自远方来，不亦乐乎。</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Is it not delightful to have friends coming from distant quarters?</td>
                    <td>中文 → EN</td>
                    <td>赵六</td>
                    <td>2024-03-15 14:00</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>TR005</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">You have been my friend. That in itself is a tremendous thing.</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">你一直是我的朋友。这本身就是一件了不起的事。</td>
                    <td>EN → 中文</td>
                    <td>钱七</td>
                    <td>2024-03-15 15:20</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>TR006</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">千里之行，始于足下。</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">A journey of a thousand miles begins with a single step.</td>
                    <td>中文 → EN</td>
                    <td>孙八</td>
                    <td>2024-03-15 16:45</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>TR007</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">What is essential is invisible to the eye.</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">真正重要的东西，用眼睛是看不见的。</td>
                    <td>EN → 中文</td>
                    <td>周九</td>
                    <td>2024-03-15 17:30</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>TR008</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">学而时习之，不亦说乎。</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Is it not pleasant to learn with a constant perseverance?</td>
                    <td>中文 → EN</td>
                    <td>吴十</td>
                    <td>2024-03-15 18:15</td>
                    <td><span class="tag tag-yellow">生成中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 156 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>
`,


aiExplain: () => `
<div class="page-title">
    <span>AI 解释管理</span>
</div>

<div class="two-col">
    <div class="card" style="flex:2;">
        <div class="card-header"><span class="card-title">⚙️ 解释提示词配置</span></div>
        <div class="card-body">
            <div class="form-group">
                <label class="form-label">解释风格</label>
                <select class="form-select">
                    <option>简洁明了</option>
                    <option>详细展开</option>
                    <option>适合儿童</option>
                    <option>学术深度</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">系统提示词</label>
                <textarea class="form-textarea" rows="4" placeholder="设定AI解释的风格和深度要求..."></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">模型选择</label>
                <select class="form-select">
                    <option>GPT-4</option>
                    <option>GPT-3.5</option>
                    <option>Claude 3</option>
                </select>
            </div>
            <div class="form-group" style="text-align:right;">
                <button class="btn btn-primary">保存配置</button>
            </div>
        </div>
    </div>
    <div class="card" style="flex:1;">
        <div class="card-header"><span class="card-title">📊 使用统计</span></div>
        <div class="card-body">
            <div class="stat-cards" style="grid-template-columns:1fr;">
                <div class="stat-card">
                    <span class="stat-value">8,921</span>
                    <span class="stat-label">总解释次数</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">1.9s</span>
                    <span class="stat-label">平均响应时间</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">97.8%</span>
                    <span class="stat-label">成功率</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><span class="card-title">📋 对话记录</span></div>
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>学生</th>
                    <th>问题</th>
                    <th>AI回复摘要</th>
                    <th>对话轮数</th>
                    <th>时间</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>EX001</td>
                    <td>张三</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">小王子为什么离开自己的星球？</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">小王子离开B-612星球是因为他和玫瑰发生了矛盾，他想要去看看外面的世界...</td>
                    <td>3</td>
                    <td>2024-03-15 10:30</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>EX002</td>
                    <td>李四</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">夏洛为什么要帮助威尔伯？</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">夏洛帮助威尔伯是因为它们之间建立了深厚的友谊，夏洛认为朋友就应该互相帮助...</td>
                    <td>5</td>
                    <td>2024-03-15 11:15</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>EX003</td>
                    <td>王五</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">孙悟空为什么要保护唐僧？</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">孙悟空被观音菩萨点化，答应保护唐僧西天取经，以此赎清自己大闹天宫的罪孽...</td>
                    <td>4</td>
                    <td>2024-03-15 12:00</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>EX004</td>
                    <td>赵六</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">哈利·波特为什么能进入霍格沃茨？</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">哈利·波特是巫师，他收到了霍格沃茨魔法学校的录取通知书，因为他是巫师界的救世主...</td>
                    <td>6</td>
                    <td>2024-03-15 13:45</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>EX005</td>
                    <td>钱七</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">草房子为什么叫草房子？</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">草房子指的是故事中用油麻搭建的房子，是主人公桑桑生活的地方...</td>
                    <td>2</td>
                    <td>2024-03-15 14:30</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>EX006</td>
                    <td>孙八</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">What does the fox mean by "tame"?</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">The fox explains that "taming" means creating ties or bonds between two beings...</td>
                    <td>7</td>
                    <td>2024-03-15 15:20</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>EX007</td>
                    <td>周九</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Why did the spider write words on the web?</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">Charlotte wrote words on her web to save Wilbur from being slaughtered...</td>
                    <td>4</td>
                    <td>2024-03-15 16:00</td>
                    <td><span class="tag tag-green">成功</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>EX008</td>
                    <td>吴十</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">How does the Sorting Hat work?</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">The Sorting Hat is a magical hat that reads the wearer's mind and personality...</td>
                    <td>3</td>
                    <td>2024-03-15 17:10</td>
                    <td><span class="tag tag-yellow">生成中</span></td>
                    <td>
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 128 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>
`,


knowledge: () => `
<div class="page-title">
    <span>知识库管理</span>
    <button class="btn btn-primary" onclick="openModal('modal-add-knowledge')"><i class="ri-add-line"></i> 新增文档</button>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>文档名称</label>
        <input type="text" class="form-input" placeholder="搜索文档">
    </div>
    <div class="filter-group">
        <label>文档类型</label>
        <select class="form-select">
            <option>全部</option>
            <option>PDF</option>
            <option>Word</option>
            <option>Markdown</option>
            <option>TXT</option>
        </select>
    </div>
    <div class="filter-group">
        <label>状态</label>
        <select class="form-select">
            <option>全部</option>
            <option>已解析</option>
            <option>解析中</option>
            <option>解析失败</option>
        </select>
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>文档名称</th>
                    <th>类型</th>
                    <th>大小</th>
                    <th>段落数</th>
                    <th>状态</th>
                    <th>上传时间</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>KB001</td>
                    <td><i class="ri-file-pdf-line" style="color:var(--danger);"></i> 阅读教育白皮书2024.pdf</td>
                    <td>PDF</td>
                    <td>2.5 MB</td>
                    <td>128</td>
                    <td><span class="tag tag-green">已解析</span></td>
                    <td>2024-01-10</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>KB002</td>
                    <td><i class="ri-file-word-line" style="color:var(--primary);"></i> 中小学阅读书目指南.docx</td>
                    <td>Word</td>
                    <td>1.2 MB</td>
                    <td>86</td>
                    <td><span class="tag tag-green">已解析</span></td>
                    <td>2024-01-15</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>KB003</td>
                    <td><i class="ri-markdown-line" style="color:var(--success);"></i> 儿童文学知识库.md</td>
                    <td>Markdown</td>
                    <td>856 KB</td>
                    <td>256</td>
                    <td><span class="tag tag-yellow">解析中</span></td>
                    <td>2024-02-20</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>KB004</td>
                    <td><i class="ri-file-text-line" style="color:var(--text-muted);"></i> 阅读理解技巧.txt</td>
                    <td>TXT</td>
                    <td>45 KB</td>
                    <td>32</td>
                    <td><span class="tag tag-green">已解析</span></td>
                    <td>2024-02-25</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>KB005</td>
                    <td><i class="ri-file-pdf-line" style="color:var(--danger);"></i> 英语分级阅读标准.pdf</td>
                    <td>PDF</td>
                    <td>3.8 MB</td>
                    <td>65</td>
                    <td><span class="tag tag-green">已解析</span></td>
                    <td>2024-03-01</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>KB006</td>
                    <td><i class="ri-file-word-line" style="color:var(--primary);"></i> 阅读教学案例分析.docx</td>
                    <td>Word</td>
                    <td>2.1 MB</td>
                    <td>42</td>
                    <td><span class="tag tag-red">解析失败</span></td>
                    <td>2024-03-05</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>KB007</td>
                    <td><i class="ri-markdown-line" style="color:var(--success);"></i> 名著导读资料.md</td>
                    <td>Markdown</td>
                    <td>1.2 MB</td>
                    <td>180</td>
                    <td><span class="tag tag-green">已解析</span></td>
                    <td>2024-03-08</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>KB008</td>
                    <td><i class="ri-file-text-line" style="color:var(--text-muted);"></i> 学生阅读习惯调研.txt</td>
                    <td>TXT</td>
                    <td>128 KB</td>
                    <td>88</td>
                    <td><span class="tag tag-yellow">解析中</span></td>
                    <td>2024-03-10</td>
                    <td>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-view-knowledge')"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" onclick="openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);" onclick="openModal('modal-delete-knowledge')"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 48 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<!-- 新增文档模态框 -->
<div class="modal-overlay" id="modal-add-knowledge">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">新增文档</span>
            <button class="modal-close" onclick="closeModal('modal-add-knowledge')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">文档名称</label>
                <input type="text" class="form-input" placeholder="请输入文档名称">
            </div>
            <div class="form-group">
                <label class="form-label">文档类型</label>
                <select class="form-select">
                    <option>PDF</option>
                    <option>Word</option>
                    <option>Markdown</option>
                    <option>TXT</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">上传文件</label>
                <div style="border:2px dashed var(--border);border-radius:8px;padding:24px;text-align:center;color:var(--text-muted);">
                    <i class="ri-upload-cloud-2-line" style="font-size:32px;"></i>
                    <p style="margin:4px 0;font-size:13px;">点击上传或拖拽文件到此处</p>
                    <p style="font-size:12px;color:var(--text-muted);">支持 PDF、Word、Markdown、TXT 格式</p>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-add-knowledge')">取消</button>
            <button class="btn btn-primary">确认上传</button>
        </div>
    </div>
</div>

<!-- 编辑文档模态框 -->
<div class="modal-overlay" id="modal-edit-knowledge">
    <div class="modal" style="max-width:520px;">
        <div class="modal-header">
            <span class="modal-title">编辑文档</span>
            <button class="modal-close" onclick="closeModal('modal-edit-knowledge')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">文档名称</label>
                <input type="text" class="form-input" value="阅读教育白皮书2024.pdf">
            </div>
            <div class="form-group">
                <label class="form-label">文档类型</label>
                <select class="form-select">
                    <option selected>PDF</option>
                    <option>Word</option>
                    <option>Markdown</option>
                    <option>TXT</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">状态</label>
                <select class="form-select">
                    <option selected>已解析</option>
                    <option>解析中</option>
                    <option>解析失败</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-edit-knowledge')">取消</button>
            <button class="btn btn-primary">保存修改</button>
        </div>
    </div>
</div>

<!-- 删除确认模态框 -->
<div class="modal-overlay" id="modal-delete-knowledge">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">确认删除</span>
            <button class="modal-close" onclick="closeModal('modal-delete-knowledge')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body" style="text-align:center;padding:32px 20px;">
            <i class="ri-error-warning-line" style="font-size:48px;color:var(--danger);margin-bottom:16px;"></i>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;">确定要删除该文档吗？</div>
            <div style="font-size:13px;color:var(--text-secondary);">删除后文档及解析内容将无法恢复</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-delete-knowledge')">取消</button>
            <button class="btn btn-danger">确认删除</button>
        </div>
    </div>
</div>

<!-- 查看知识库文档模态框 -->
<div class="modal-overlay" id="modal-view-knowledge">
    <div class="modal" style="max-width:600px;">
        <div class="modal-header">
            <span class="modal-title">知识库文档详情</span>
            <button class="modal-close" onclick="closeModal('modal-view-knowledge')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div style="display:flex;gap:16px;margin-bottom:16px;">
                <div style="flex:1;">
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">文档标题</div>
                    <div style="font-size:14px;font-weight:500;">文学作品赏析指南</div>
                </div>
                <div style="flex:1;">
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">类型</div>
                    <div style="font-size:14px;font-weight:500;">PDF</div>
                </div>
                <div style="flex:1;">
                    <div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">大小</div>
                    <div style="font-size:14px;font-weight:500;">2.5MB</div>
                </div>
            </div>
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:8px;">文档摘要</div>
            <div style="padding:12px;background:var(--bg);border-radius:var(--radius);font-size:13px;line-height:1.6;color:var(--text-secondary);margin-bottom:16px;">
                本文档收录了经典文学作品的深度赏析，包括主题解读、人物分析、写作手法等内容，适用于小学高年级和初中学生的课外阅读指导。
            </div>
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:8px;">关联书籍</div>
            <div style="display:flex;flex-wrap:wrap;gap:8px;">
                <span class="tag">小王子</span>
                <span class="tag">夏洛的网</span>
                <span class="tag">草房子</span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-view-knowledge')">关闭</button>
            <button class="btn btn-primary" onclick="closeModal('modal-view-knowledge');openModal('modal-edit-knowledge')"><i class="ri-edit-line"></i> 编辑</button>
        </div>
    </div>
</div>
`,


});
