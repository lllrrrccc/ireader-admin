Object.assign(pageFunctions, {
readingData: () => `
<div class="page-title">
    <span>学生阅读数据</span>
    <button class="btn btn-primary"><i class="ri-download-line"></i> 导出数据</button>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>学生ID</label>
        <input type="text" class="form-input" placeholder="输入学生ID">
    </div>
    <div class="filter-group">
        <label>书籍</label>
        <input type="text" class="form-input" placeholder="书籍名称">
    </div>
    <div class="filter-group">
        <label>阅读状态</label>
        <select class="form-select">
            <option>全部</option>
            <option>未开始</option>
            <option>阅读中</option>
            <option>已读完</option>
        </select>
    </div>
    <div class="filter-group">
        <label>加入书架</label>
        <select class="form-select">
            <option>全部</option>
            <option>已加入</option>
            <option>未加入</option>
        </select>
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
    </div>
</div>

<div class="card">
    <div class="card-body" style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>学生阅读ID</th>
                    <th>学生ID</th>
                    <th>学生</th>
                    <th>书籍ID</th>
                    <th>书名</th>
                    <th>首次打开时间</th>
                    <th>加入书架</th>
                    <th>阅读状态</th>
                    <th>最近阅读进度</th>
                    <th>最近阅读时间</th>
                    <th>笔记/读后感</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>SR001</td>
                    <td>S001</td>
                    <td>张三</td>
                    <td>B001</td>
                    <td>小王子</td>
                    <td>2023-09-15</td>
                    <td><span class="tag tag-green">已加入</span></td>
                    <td><span class="tag tag-green">已读完</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:100%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">100%</span>
                        </div>
                    </td>
                    <td>2024-03-15</td>
                    <td>笔记 3 / 读后感 1</td>
                </tr>
                <tr>
                    <td>SR002</td>
                    <td>S001</td>
                    <td>张三</td>
                    <td>B002</td>
                    <td>夏洛的网</td>
                    <td>2023-10-01</td>
                    <td><span class="tag tag-green">已加入</span></td>
                    <td><span class="tag tag-blue">阅读中</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:65%;height:100%;background:var(--primary);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">65%</span>
                        </div>
                    </td>
                    <td>2024-03-14</td>
                    <td>笔记 1 / 读后感 0</td>
                </tr>
                <tr>
                    <td>SR003</td>
                    <td>S002</td>
                    <td>李四</td>
                    <td>B001</td>
                    <td>小王子</td>
                    <td>2023-09-20</td>
                    <td><span class="tag tag-gray">未加入</span></td>
                    <td><span class="tag tag-blue">阅读中</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:45%;height:100%;background:var(--primary);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">45%</span>
                        </div>
                    </td>
                    <td>2024-03-13</td>
                    <td>笔记 0 / 读后感 0</td>
                </tr>
                <tr>
                    <td>SR004</td>
                    <td>S003</td>
                    <td>王五</td>
                    <td>B003</td>
                    <td>西游记</td>
                    <td>2023-11-01</td>
                    <td><span class="tag tag-green">已加入</span></td>
                    <td><span class="tag tag-blue">阅读中</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:12%;height:100%;background:var(--warning);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">12%</span>
                        </div>
                    </td>
                    <td>2024-03-15</td>
                    <td>笔记 2 / 读后感 0</td>
                </tr>
                <tr>
                    <td>SR005</td>
                    <td>S004</td>
                    <td>赵六</td>
                    <td>B004</td>
                    <td>哈利·波特与魔法石</td>
                    <td>2024-01-05</td>
                    <td><span class="tag tag-green">已加入</span></td>
                    <td><span class="tag tag-blue">阅读中</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:30%;height:100%;background:var(--warning);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">30%</span>
                        </div>
                    </td>
                    <td>2024-03-11</td>
                    <td>笔记 0 / 读后感 0</td>
                </tr>
                <tr>
                    <td>SR006</td>
                    <td>S005</td>
                    <td>钱七</td>
                    <td>B005</td>
                    <td>草房子</td>
                    <td>2023-10-15</td>
                    <td><span class="tag tag-green">已加入</span></td>
                    <td><span class="tag tag-green">已读完</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:100%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">100%</span>
                        </div>
                    </td>
                    <td>2024-03-12</td>
                    <td>笔记 1 / 读后感 1</td>
                </tr>
                <tr>
                    <td>SR007</td>
                    <td>S006</td>
                    <td>孙八</td>
                    <td>B006</td>
                    <td>狼王梦</td>
                    <td>2024-02-01</td>
                    <td><span class="tag tag-gray">未加入</span></td>
                    <td><span class="tag tag-gray">未开始</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:0%;height:100%;background:var(--text-muted);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">0%</span>
                        </div>
                    </td>
                    <td>—</td>
                    <td>笔记 0 / 读后感 0</td>
                </tr>
                <tr>
                    <td>SR008</td>
                    <td>S007</td>
                    <td>周九</td>
                    <td>B007</td>
                    <td>The Little Prince</td>
                    <td>2023-12-01</td>
                    <td><span class="tag tag-green">已加入</span></td>
                    <td><span class="tag tag-green">已读完</span></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:100%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">100%</span>
                        </div>
                    </td>
                    <td>2024-03-10</td>
                    <td>笔记 2 / 读后感 1</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 256 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>
`,


readingTasks: () => `
<div class="page-title">
    <span>阅读任务</span>
    <button class="btn btn-primary" onclick="openModal('modal-add-task')"><i class="ri-add-line"></i> 新增任务</button>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>老师ID</label>
        <input type="text" class="form-input" placeholder="输入老师ID">
    </div>
    <div class="filter-group">
        <label>任务名称</label>
        <input type="text" class="form-input" placeholder="搜索任务">
    </div>
    <div class="filter-group">
        <label>书籍名称</label>
        <input type="text" class="form-input" placeholder="书籍名称">
    </div>
    <div class="filter-group">
        <label>状态</label>
        <select class="form-select">
            <option>全部</option>
            <option>进行中</option>
            <option>已结束</option>
            <option>未开始</option>
        </select>
    </div>
    <div class="filter-group">
        <label>时间范围</label>
        <input type="date" class="form-input" style="margin-bottom:4px;">
        <input type="date" class="form-input">
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
        <button class="btn btn-primary"><i class="ri-download-line"></i> 导出</button>
    </div>
</div>

<div class="card">
    <div class="card-body" style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>任务名称</th>
                    <th>创建老师ID</th>
                    <th>书籍</th>
                    <th>关联班级</th>
                    <th>覆盖学生数量</th>
                    <th>任务时间</th>
                    <th>完成率</th>
                    <th>状态</th>
                    <th style="width:200px;">操作</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>寒假阅读挑战</td>
                    <td>T001</td>
                    <td>小王子</td>
                    <td>三(1)班, 三(2)班</td>
                    <td>120</td>
                    <td>2024-01-20 ~ 2024-02-20</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:60px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:85%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">85%</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">进行中</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openModal('modal-edit-task')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>每日阅读30分钟</td>
                    <td>T001</td>
                    <td>任意</td>
                    <td>三(1)班</td>
                    <td>200</td>
                    <td>2024-03-01 ~ 2024-03-31</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:60px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:62%;height:100%;background:var(--primary);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">62%</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">进行中</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openModal('modal-edit-task')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>春季阅读马拉松</td>
                    <td>T002</td>
                    <td>夏洛的网</td>
                    <td>五(3)班</td>
                    <td>150</td>
                    <td>2024-04-01 ~ 2024-04-30</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:60px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:0%;height:100%;background:var(--text-muted);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">0%</span>
                        </div>
                    </td>
                    <td><span class="tag tag-yellow">未开始</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openModal('modal-edit-task')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>英语原版阅读周</td>
                    <td>T002</td>
                    <td>The Little Prince</td>
                    <td>五(3)班</td>
                    <td>80</td>
                    <td>2024-02-15 ~ 2024-02-22</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:60px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:100%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">100%</span>
                        </div>
                    </td>
                    <td><span class="tag tag-green">已结束</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openModal('modal-edit-task')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>国学经典诵读</td>
                    <td>T001</td>
                    <td>西游记</td>
                    <td>三(2)班</td>
                    <td>90</td>
                    <td>2024-03-10 ~ 2024-05-10</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:60px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:25%;height:100%;background:var(--warning);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">25%</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">进行中</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openModal('modal-edit-task')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
                <tr>
                    <td>暑假阅读计划</td>
                    <td>T004</td>
                    <td>哈利·波特</td>
                    <td>四(2)班</td>
                    <td>250</td>
                    <td>2024-07-01 ~ 2024-08-31</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:60px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:0%;height:100%;background:var(--text-muted);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">0%</span>
                        </div>
                    </td>
                    <td><span class="tag tag-yellow">未开始</span></td>
                    <td style="white-space:nowrap;">
                        <button class="btn btn-link btn-sm"><i class="ri-eye-line"></i> 查看</button>
                        <button class="btn btn-link btn-sm" style="color:var(--warning);" onclick="openModal('modal-edit-task')"><i class="ri-edit-line"></i> 编辑</button>
                        <button class="btn btn-link btn-sm" style="color:var(--danger);"><i class="ri-delete-bin-line"></i> 删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 128 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>

<!-- 新增任务模态框 -->
<div class="modal-overlay" id="modal-add-task">
    <div class="modal" style="max-width:600px;">
        <div class="modal-header">
            <span class="modal-title">新增阅读任务</span>
            <button class="modal-close" onclick="closeModal('modal-add-task')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">任务名称 <span style="color:var(--danger);">*</span></label>
                <input type="text" class="form-input" placeholder="请输入任务名称">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group">
                    <label class="form-label">任务类型 <span style="color:var(--danger);">*</span></label>
                    <select class="form-select">
                        <option>整书阅读</option>
                        <option>每日阅读</option>
                        <option>章节阅读</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">目标书籍</label>
                    <input type="text" class="form-input" placeholder="搜索书籍">
                </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group">
                    <label class="form-label">开始时间 <span style="color:var(--danger);">*</span></label>
                    <input type="date" class="form-input">
                </div>
                <div class="form-group">
                    <label class="form-label">结束时间 <span style="color:var(--danger);">*</span></label>
                    <input type="date" class="form-input">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">目标描述</label>
                <input type="text" class="form-input" placeholder="如：阅读120页、每天30分钟">
            </div>
            <div class="form-group">
                <label class="form-label">选择班级 <span style="color:var(--danger);">*</span></label>
                <input type="text" class="form-input" placeholder="选择目标班级或学生">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-add-task')">取消</button>
            <button class="btn btn-primary">确认创建</button>
        </div>
    </div>
</div>

<!-- 编辑任务模态框 -->
<div class="modal-overlay" id="modal-edit-task">
    <div class="modal" style="max-width:600px;">
        <div class="modal-header">
            <span class="modal-title">编辑阅读任务</span>
            <button class="modal-close" onclick="closeModal('modal-edit-task')"><i class="ri-close-line"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">任务名称 <span style="color:var(--danger);">*</span></label>
                <input type="text" class="form-input" value="寒假阅读挑战">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group">
                    <label class="form-label">任务类型 <span style="color:var(--danger);">*</span></label>
                    <select class="form-select">
                        <option selected>整书阅读</option>
                        <option>每日阅读</option>
                        <option>章节阅读</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">目标书籍</label>
                    <input type="text" class="form-input" value="小王子">
                </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group">
                    <label class="form-label">开始时间 <span style="color:var(--danger);">*</span></label>
                    <input type="date" class="form-input" value="2024-01-20">
                </div>
                <div class="form-group">
                    <label class="form-label">结束时间 <span style="color:var(--danger);">*</span></label>
                    <input type="date" class="form-input" value="2024-02-20">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">目标描述</label>
                <input type="text" class="form-input" value="120页">
            </div>
            <div class="form-group">
                <label class="form-label">选择班级 <span style="color:var(--danger);">*</span></label>
                <input type="text" class="form-input" value="三(1)班, 三(2)班">
            </div>
            <div class="form-group">
                <label class="form-label">状态</label>
                <select class="form-select">
                    <option selected>进行中</option>
                    <option>已结束</option>
                    <option>未开始</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('modal-edit-task')">取消</button>
            <button class="btn btn-primary">保存修改</button>
        </div>
    </div>
</div>
`,


wordLearning: () => `
<div class="page-title">
    <span>学生背单词</span>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>学生ID</label>
        <input type="text" class="form-input" placeholder="输入学生ID">
    </div>
    <div class="filter-group">
        <label>设备SN码</label>
        <input type="text" class="form-input" placeholder="输入设备SN码">
    </div>
    <div class="filter-group">
        <label>词表ID</label>
        <input type="text" class="form-input" placeholder="输入词表ID">
    </div>
    <div class="filter-group">
        <label>词表名称</label>
        <input type="text" class="form-input" placeholder="词库名称">
    </div>
    <div class="filter-group">
        <label>阅读级别</label>
        <select class="form-select">
            <option>全部</option>
            <option>Level 1</option>
            <option>Level 2</option>
            <option>Level 3</option>
            <option>Level 4</option>
            <option>Level 5</option>
        </select>
    </div>
    <div class="filter-group">
        <label>状态</label>
        <select class="form-select">
            <option>全部</option>
            <option>未学习</option>
            <option>学习中</option>
            <option>已掌握</option>
        </select>
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
    </div>
</div>

<div class="card">
    <div class="card-body" style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>学生ID</th>
                    <th>学生姓名</th>
                    <th>词库ID</th>
                    <th>词库名称</th>
                    <th>最近背单词时间</th>
                    <th>进度（已学/总数）</th>
                    <th>掌握状态</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>S001</td>
                    <td>张三</td>
                    <td>W001</td>
                    <td>小王子核心词汇</td>
                    <td>2024-03-15</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:67%;height:100%;background:var(--success);"></div>
                            </div>
                            <span style="font-size:12px;">86/128</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
                <tr>
                    <td>S002</td>
                    <td>李四</td>
                    <td>W002</td>
                    <td>夏洛的网高频词</td>
                    <td>2024-03-14</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:47%;height:100%;background:var(--warning);"></div>
                            </div>
                            <span style="font-size:12px;">45/95</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
                <tr>
                    <td>S003</td>
                    <td>王五</td>
                    <td>W001</td>
                    <td>小王子核心词汇</td>
                    <td>2024-03-15</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:94%;height:100%;background:var(--success);"></div>
                            </div>
                            <span style="font-size:12px;">120/128</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
                <tr>
                    <td>S004</td>
                    <td>赵六</td>
                    <td>W003</td>
                    <td>哈利波特魔法词汇</td>
                    <td>2024-03-13</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:60%;height:100%;background:var(--primary);"></div>
                            </div>
                            <span style="font-size:12px;">120/200</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
                <tr>
                    <td>S005</td>
                    <td>钱七</td>
                    <td>W004</td>
                    <td>小学英语基础词汇</td>
                    <td>2024-03-12</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:70%;height:100%;background:var(--success);"></div>
                            </div>
                            <span style="font-size:12px;">350/500</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
                <tr>
                    <td>S006</td>
                    <td>孙八</td>
                    <td>W005</td>
                    <td>外研社分级词汇 L1</td>
                    <td>2024-03-11</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:50%;height:100%;background:var(--primary);"></div>
                            </div>
                            <span style="font-size:12px;">40/80</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
                <tr>
                    <td>S007</td>
                    <td>周九</td>
                    <td>W006</td>
                    <td>外研社分级词汇 L3</td>
                    <td>2024-03-15</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:50%;height:100%;background:var(--primary);"></div>
                            </div>
                            <span style="font-size:12px;">90/180</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
                <tr>
                    <td>S008</td>
                    <td>吴十</td>
                    <td>W007</td>
                    <td>西游记成语典故</td>
                    <td>2024-03-10</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:120px;height:8px;background:var(--bg);border-radius:4px;overflow:hidden;">
                                <div style="width:50%;height:100%;background:var(--primary);"></div>
                            </div>
                            <span style="font-size:12px;">128/256</span>
                        </div>
                    </td>
                    <td><span class="tag tag-blue">学习中</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 256 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>
`,


listeningData: () => `
<div class="page-title">
    <span>学生听力数据</span>
</div>

<div class="filter-bar">
    <div class="filter-group">
        <label>学生ID</label>
        <input type="text" class="form-input" placeholder="输入学生ID">
    </div>
    <div class="filter-group">
        <label>听力内容ID</label>
        <input type="text" class="form-input" placeholder="输入听力ID">
    </div>
    <div class="filter-group">
        <label>听力标题</label>
        <input type="text" class="form-input" placeholder="搜索听力">
    </div>
    <div class="filter-group">
        <label>完成状态</label>
        <select class="form-select">
            <option>全部</option>
            <option>未开始</option>
            <option>进行中</option>
            <option>已完成</option>
        </select>
    </div>
    <div class="filter-group" style="align-self:flex-end;">
        <button class="btn btn-primary"><i class="ri-search-line"></i> 查询</button>
        <button class="btn btn-secondary">重置</button>
    </div>
</div>

<div class="card">
    <div class="card-body" style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th>学生ID</th>
                    <th>学生姓名</th>
                    <th>听力内容ID</th>
                    <th>听力标题</th>
                    <th>播放进度</th>
                    <th>已听次数</th>
                    <th>最后播放</th>
                    <th>状态</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>S001</td>
                    <td>张三</td>
                    <td>L001</td>
                    <td>小王子 - 第一章</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:100%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">100%</span>
                        </div>
                    </td>
                    <td>3</td>
                    <td>2024-03-15</td>
                    <td><span class="tag tag-green">已完成</span></td>
                </tr>
                <tr>
                    <td>S002</td>
                    <td>李四</td>
                    <td>L002</td>
                    <td>夏洛的网 - 第一章</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:57%;height:100%;background:var(--primary);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">57%</span>
                        </div>
                    </td>
                    <td>2</td>
                    <td>2024-03-14</td>
                    <td><span class="tag tag-blue">进行中</span></td>
                </tr>
                <tr>
                    <td>S003</td>
                    <td>王五</td>
                    <td>L003</td>
                    <td>The Little Prince - Ch.1</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:0%;height:100%;background:var(--text-muted);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">0%</span>
                        </div>
                    </td>
                    <td>0</td>
                    <td>—</td>
                    <td><span class="tag tag-gray">未开始</span></td>
                </tr>
                <tr>
                    <td>S004</td>
                    <td>赵六</td>
                    <td>L004</td>
                    <td>哈利波特 - 第一章</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:29%;height:100%;background:var(--warning);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">29%</span>
                        </div>
                    </td>
                    <td>1</td>
                    <td>2024-03-13</td>
                    <td><span class="tag tag-blue">进行中</span></td>
                </tr>
                <tr>
                    <td>S005</td>
                    <td>钱七</td>
                    <td>L005</td>
                    <td>草房子 - 第一章</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:100%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">100%</span>
                        </div>
                    </td>
                    <td>2</td>
                    <td>2024-03-12</td>
                    <td><span class="tag tag-green">已完成</span></td>
                </tr>
                <tr>
                    <td>S006</td>
                    <td>孙八</td>
                    <td>L006</td>
                    <td>狼王梦 - 第一章</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:0%;height:100%;background:var(--text-muted);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">0%</span>
                        </div>
                    </td>
                    <td>0</td>
                    <td>—</td>
                    <td><span class="tag tag-gray">未开始</span></td>
                </tr>
                <tr>
                    <td>S007</td>
                    <td>周九</td>
                    <td>L007</td>
                    <td>小王子 - 第二章</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:100%;height:100%;background:var(--success);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">100%</span>
                        </div>
                    </td>
                    <td>4</td>
                    <td>2024-03-15</td>
                    <td><span class="tag tag-green">已完成</span></td>
                </tr>
                <tr>
                    <td>S008</td>
                    <td>吴十</td>
                    <td>L008</td>
                    <td>宝葫芦的秘密 - 第一章</td>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <div style="width:80px;height:6px;background:var(--bg);border-radius:3px;"><div style="width:30%;height:100%;background:var(--warning);border-radius:3px;"></div></div>
                            <span style="font-size:12px;">30%</span>
                        </div>
                    </td>
                    <td>1</td>
                    <td>2024-03-11</td>
                    <td><span class="tag tag-blue">进行中</span></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="pagination-bar">
    <span>共 256 条记录</span>
    <div class="pagination">
        <button class="btn btn-sm btn-secondary" disabled><i class="ri-arrow-left-s-line"></i></button>
        <button class="btn btn-sm btn-primary">1</button>
        <button class="btn btn-sm btn-secondary">2</button>
        <button class="btn btn-sm btn-secondary">3</button>
        <button class="btn btn-sm btn-secondary">4</button>
        <button class="btn btn-sm btn-secondary">5</button>
        <button class="btn btn-sm btn-secondary"><i class="ri-arrow-right-s-line"></i></button>
    </div>
</div>
`,


});
