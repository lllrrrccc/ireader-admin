// Core framework: navigation, routing, breadcrumb, init
let currentPage = 'books';
let sidebarCollapsed = false;
let isLoggedIn = false;

function init() {
    // 初始显示登录页，隐藏主应用
    document.getElementById('login-page').style.display = 'flex';
    document.getElementById('main-app').style.display = 'none';
}


function doLogin() {
    // 模拟登录成功
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('main-app').style.display = 'flex';
    isLoggedIn = true;
    renderSidebar();
    loadPage(currentPage);
    updateBreadcrumb(currentPage);
    setupEventListeners();
}


function renderSidebar() {
    const nav = document.getElementById('sidebar-nav');
    nav.innerHTML = navConfig.map(group => `
        <div class="nav-group">
            <div class="nav-group-title">${group.group}</div>
            ${group.items.map(item => `
                <a class="nav-item ${item.page === currentPage ? 'active' : ''}" 
                   data-page="${item.page}" onclick="navigateTo('${item.page}')">
                    <i class="${item.icon}"></i>
                    <span>${item.label}</span>
                </a>
            `).join('')}
        </div>
    `).join('');
}


function navigateTo(page) {
    currentPage = page;
    renderSidebar();
    loadPage(page);
    updateBreadcrumb(page);
    
    // 移动端自动关闭侧边栏
    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('open');
    }
}


function updateBreadcrumb(page) {
    let label = '书籍管理';
    for (const group of navConfig) {
        const item = group.items.find(i => i.page === page);
        if (item) {
            label = item.label;
            break;
        }
    }
    // 特殊页面不在导航配置中
    const extraPages = {
        'batchAddBooks': '批量新增书籍',
        'bookDetail': '书籍详情',
        'bookAudio': '音频管理',
        'bookTranslation': '译文管理',
        'audioAlignment': '音文对齐',
        'audioAlignmentEn': '音文对齐',
        'audioRange': '段落配置',
        'studentDetail': '学生详情',
        'deviceStudents': '设备学生绑定'
    };
    if (extraPages[page]) {
        label = extraPages[page];
    }
    document.getElementById('breadcrumb').textContent = label;
}


function loadPage(page) {
    const container = document.getElementById('page-container');
    container.innerHTML = '';
    
    const pageFn = pageFunctions[page];
    if (pageFn) {
        container.innerHTML = pageFn();
        attachPageEvents(page);
    } else {
        container.innerHTML = '<div class="empty-state"><i class="ri-error-warning-line"></i><p>页面未找到</p></div>';
    }
}


function setupEventListeners() {
    // 菜单折叠
    document.getElementById('menu-toggle').addEventListener('click', () => {
        sidebarCollapsed = !sidebarCollapsed;
        document.getElementById('sidebar').classList.toggle('collapsed', sidebarCollapsed);
    });
    
    // 移动端点击遮罩关闭
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 768) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('menu-toggle');
            if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        }
    });
}


function attachPageEvents(page) {
    // 页面特定事件绑定
}

// 模态框工具函数

